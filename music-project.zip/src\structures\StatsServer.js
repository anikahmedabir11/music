const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const os = require("os");

/**
 * stats-server.js
 * ----------------
 * REST API that powers the "Live Stats" and "Viewer Count" sections on the
 * website (index.html). Matches the fetch calls already wired up there:
 *
 *   GET  /stats             -> bot + system stats, same numbers as /stats in Discord
 *   POST /viewer-heartbeat  -> { id }  marks a browser tab as "currently viewing"
 *   GET  /viewers           -> { count }  people actively on the site right now
 *   POST /view-ping         -> increments the all-time page view counter
 *   GET  /total-views       -> { total }  all-time page views (persisted to disk)
 *
 * Usage (in your main bot file, after client.connect()):
 *
 *   const StatsServer = require("./src/structures/StatsServer");
 *   client.statsServer = new StatsServer(client, {
 *     port: process.env.STATS_API_PORT || 3001,
 *     corsOrigin: "https://YOURDOMAIN.com", // your real site domain
 *   });
 *
 * Then in index.html, replace:
 *   const VIEWERS_API_BASE = "https://api.yourdomain.com";
 *   const STATS_API_URL   = "https://api.yourdomain.com/stats";
 * with your real API domain (see hosting notes at the bottom of this file).
 */
class StatsServer {
  constructor(client, opts = {}) {
    this.client = client;
    this.port = opts.port || 3001;
    this.corsOrigin = opts.corsOrigin || "*";
    this.dataFile =
      opts.dataFile || path.join(__dirname, "..", "..", "viewdata.json");

    // viewerId -> last heartbeat timestamp (ms)
    this.activeViewers = new Map();
    this.viewerTimeoutMs = opts.viewerTimeoutMs || 25000; // drop after ~2.5 missed pings

    this.totalViews = this.loadTotalViews();

    this.app = express();
    this.app.use(cors({ origin: "*" }));
    this.app.use(express.json());
    this.app.use(express.static(path.join(__dirname, "..", "..", "public")));

    this.registerRoutes();

    this.server = this.app.listen(this.port, () => {
      console.log(`[StatsServer] REST API listening on :${this.port}`);
    });

    // sweep stale viewers periodically
    this.sweepTimer = setInterval(() => this.sweepViewers(), 10000);
  }

  // ---------- persistence ----------

  loadTotalViews() {
    try {
      const raw = fs.readFileSync(this.dataFile, "utf8");
      const parsed = JSON.parse(raw);
      return Number(parsed.totalViews) || 0;
    } catch {
      return 0; // file doesn't exist yet or is unreadable — start fresh
    }
  }

  saveTotalViews() {
    try {
      fs.writeFileSync(
        this.dataFile,
        JSON.stringify({ totalViews: this.totalViews }, null, 2)
      );
    } catch (err) {
      console.log("[StatsServer] failed to persist view count:", err.message);
    }
  }

  // ---------- viewer tracking ----------

  sweepViewers() {
    const now = Date.now();
    for (const [id, lastSeen] of this.activeViewers) {
      if (now - lastSeen > this.viewerTimeoutMs) {
        this.activeViewers.delete(id);
      }
    }
  }

  // ---------- bot stats ----------

  gatherStats() {
    const client = this.client;
    const manager = client.manager;
    const players = manager ? Array.from(manager.players.values()) : [];
    const totalPlayers = players.length;
    const playingPlayers = players.filter((p) => p.playing).length;
    const idlePlayers = totalPlayers - playingPlayers;

    const cpuModel = os.cpus()[0]?.model.split(" @")[0].trim();
    const platform =
      os.platform().charAt(0).toUpperCase() + os.platform().slice(1);
    const load = os.loadavg();
    const cpuLoad = Number(((load[0] * 100) / os.cpus().length).toFixed(1));
    const ramMB = Number((process.memoryUsage().rss / 1024 / 1024).toFixed(2));

    return {
      servers: client.guilds.cache.size,
      users: client.users.cache.size,
      shard: `${(client.shard?.ids?.[0] ?? 0) + 1}/${client.shard?.count || 1}`,
      players: totalPlayers,
      playing: playingPlayers,
      idle: idlePlayers,
      ping: client.ws.ping,
      uptimeSeconds: Math.floor(process.uptime()),
      cpu: cpuModel,
      cpuLoad,
      ramMB,
      os: platform,
      node: process.version,
      djs: `v${require("discord.js").version}`,
    };
  }

  // ---------- routes ----------

  registerRoutes() {
    const app = this.app;

    app.get("/stats", (req, res) => {
      res.json(this.gatherStats());
    });

    app.post("/viewer-heartbeat", (req, res) => {
      const id = req.body?.id;
      if (!id || typeof id !== "string") {
        return res.status(400).json({ error: "missing id" });
      }
      this.activeViewers.set(id, Date.now());
      res.json({ ok: true });
    });

    app.get("/viewers", (req, res) => {
      res.json({ count: this.activeViewers.size });
    });

    app.post("/view-ping", (req, res) => {
      this.totalViews += 1;
      this.saveTotalViews();
      res.json({ ok: true });
    });

    app.get("/total-views", (req, res) => {
      res.json({ total: this.totalViews });
    });
  }

  stop() {
    clearInterval(this.sweepTimer);
    this.server.close();
  }
}

module.exports = StatsServer;

/**
 * Hosting notes:
 * - npm install express cors
 * - Run this behind your reverse proxy (nginx/Caddy) so it's reachable as
 *   https://api.yourdomain.com (TLS + your real domain), forwarding to
 *   127.0.0.1:3001 (or whatever STATS_API_PORT you set).
 * - Set corsOrigin to your actual site origin (e.g. "https://zyvora.xyz")
 *   instead of "*" once you're live, so random sites can't hit your API.
 * - viewdata.json is created next to your bot's root folder automatically —
 *   make sure that path is writable.
 */
