# 🌌 Zyvora Music Bot

<p align="center">
  <strong>An advanced, multi-purpose Discord bot featuring premium music playback, high-grade security, and robust utility features.</strong>
</p>

---

## 🌟 Features

- **🎵 Premium Music Playback**: Powered by [Shoukaku](https://github.com/Deivu/Shoukaku) & [Kazagumo](https://github.com/Takiyo0/Kazagumo). Supports Spotify integration, Last.fm, custom songcards (quartz, canvafy, musicard), and filters.
- **🛡️ Antinuke & Security**: Advanced server protection to prevent nukes, unauthorized bot invites, and channel/role vandalism.
- **🤖 Automod & Moderation**: Auto-moderation systems alongside standard moderation utilities to keep your server clean.
- **🎫 Interactive Tickets**: Easy-to-use support ticket systems using buttons and modals.
- **🎁 Giveaways**: Host and manage server giveaways with specific requirements.
- **📊 Stats API**: Built-in stats server displaying cluster and shard statistics.
- **⚙️ Customization**: Configure custom prefixes, favorite tracks list, and more.

---

## 🛠️ How to Host

### Prerequisites
- [Node.js](https://nodejs.org/) (Version 18.x or higher, v20+ recommended)
- A **Discord Bot Token** (obtain from the [Discord Developer Portal](https://discord.com/developers/applications))
- A running **Lavalink Server** (or use public Lavalink nodes)

### 🚀 Setup Instructions

1. **Clone the repository & Install Dependencies:**
   ```bash
   npm install
   ```

2. **Configuration:**
   Open the file `src/config.json` and fill in the required fields:
   ```json
   {
     "token": "YOUR_DISCORD_BOT_TOKEN",
     "clientId": "YOUR_CLIENT_ID",
     "prefix": ".",
     "ownerID": [
       "YOUR_USER_ID"
     ],
     "SpotifyID": "YOUR_SPOTIFY_ID",
     "SpotifySecret": "YOUR_SPOTIFY_SECRET",
     "nodes": [
       {
         "name": "Node Name",
         "url": "Lavalink_host:port",
         "auth": "Lavalink_password",
         "secure": false
       }
     ]
   }
   ```

3. **Running the Bot:**
   - **Production Mode:**
     ```bash
     npm run start
     ```
   - **Development Mode:**
     ```bash
     npm run dev
     ```

---

## 👥 Credits & Info

### 💻 Code Provider
- [realmalice](https://github.com/realmalice)

### 🔓 Leakers
- [𝙲 𝛂 𝛊 𝛞 𝛐 𝚣](https://discord.com/users/861847026923995137)
- [Mik3y🥀](https://discord.com/users/980000051562700820)

### 💬 Community & Support
- Join our server: [Vibe coders <3](https://discord.gg/uAwY7pfwfS)
