// Auto-detect the API Base URL based on current host
const API_BASE = window.location.origin;

// Command Category Tabs Toggle
const tabs = document.querySelectorAll('.tab-btn');
const contents = document.querySelectorAll('.command-category-content');

tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        contents.forEach(c => c.classList.remove('active'));

        tab.classList.add('active');
        const category = tab.getAttribute('data-category');
        document.getElementById(`cat-${category}`).classList.add('active');
    });
});

// Unique Viewer ID Setup (Stored in SessionStorage for current tab tracking)
let viewerId = sessionStorage.getItem('zyvora_viewer_id');
if (!viewerId) {
    viewerId = 'v_' + Math.random().toString(36).substr(2, 9);
    sessionStorage.setItem('zyvora_viewer_id', viewerId);
}

// -------------------------------------------------------------
// Live Statistics and Visitor Tracking Logic
// -------------------------------------------------------------

async function updateStats() {
    try {
        const response = await fetch(`${API_BASE}/stats`);
        if (!response.ok) throw new Error('API server down');
        
        const data = await response.json();
        
        // Update DOM elements
        document.getElementById('stat-servers').innerText = data.servers.toLocaleString();
        document.getElementById('stat-users').innerText = data.users.toLocaleString();
        document.getElementById('stat-playing').innerText = data.playing.toLocaleString();
        document.getElementById('stat-ping').innerText = `${data.ping} ms`;

        // Update live bot avatar
        if (data.avatar) {
            const avatarEl = document.getElementById('bot-avatar');
            if (avatarEl) avatarEl.src = data.avatar;
        }
    } catch (err) {
        console.warn('[Anik X Cheats Web] Failed to fetch stats. API is offline or booting.');
    }
}

async function sendViewerHeartbeat() {
    try {
        await fetch(`${API_BASE}/viewer-heartbeat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: viewerId })
        });
    } catch (err) {
        // Silent catch
    }
}

async function fetchActiveViewers() {
    try {
        const response = await fetch(`${API_BASE}/viewers`);
        const data = await response.json();
        document.getElementById('active-viewers').innerText = data.count || 1;
    } catch (err) {
        // Silent catch
    }
}

async function sendPagePing() {
    // Only increment view count once per unique visit session
    const hasPinged = sessionStorage.getItem('zyvora_has_pinged');
    if (!hasPinged) {
        try {
            await fetch(`${API_BASE}/view-ping`, { method: 'POST' });
            sessionStorage.setItem('zyvora_has_pinged', 'true');
        } catch (err) {
            // Silent catch
        }
    }
}

async function fetchTotalViews() {
    try {
        const response = await fetch(`${API_BASE}/total-views`);
        const data = await response.json();
        document.getElementById('total-views').innerText = data.total.toLocaleString();
    } catch (err) {
        document.getElementById('total-views').innerText = '---';
    }
}

// Initial Bootstrap
async function init() {
    await sendPagePing();
    await updateStats();
    await sendViewerHeartbeat();
    await fetchActiveViewers();
    await fetchTotalViews();

    // Intervals
    setInterval(updateStats, 15000); // refresh system stats every 15s
    setInterval(sendViewerHeartbeat, 10000); // ping heartbeat every 10s
    setInterval(fetchActiveViewers, 10000); // refresh active viewer count every 10s
}

window.onload = init;
