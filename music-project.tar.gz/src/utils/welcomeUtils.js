const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

function ordinal(n) {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

/**
 * Replaces {placeholder} tokens in a template string with real values.
 * Supported: {user}, {user.mention}, {user.tag}, {user.name}, {user.id},
 * {server}, {server.name}, {server.id}, {membercount}, {membercount.ordinal}
 */
function parsePlaceholders(template, member) {
  if (!template) return "";
  const guild = member.guild;
  const memberCount = guild.memberCount;

  const map = {
    "{user}": `${member.user.username}`,
    "{user.mention}": `<@${member.id}>`,
    "{user.tag}": member.user.tag || member.user.username,
    "{user.name}": member.user.username,
    "{user.id}": member.id,
    "{server}": guild.name,
    "{server.name}": guild.name,
    "{server.id}": guild.id,
    "{membercount}": `${memberCount}`,
    "{membercount.ordinal}": ordinal(memberCount),
  };

  let result = template;
  for (const [token, value] of Object.entries(map)) {
    result = result.split(token).join(value);
  }
  return result;
}

/**
 * Builds the welcome embed for a member using their guild's welcome settings.
 */
function buildWelcomeEmbed(settings, member) {
  const description = parsePlaceholders(settings.message, member);

  const embed = new EmbedBuilder()
    .setColor(parseInt(settings.color || "8A5CFF", 16))
    .setDescription(description)
    .setTimestamp();

  if (settings.authorEnabled) {
    embed.setAuthor({
      name: parsePlaceholders(settings.authorText || "{user}", member),
      iconURL: member.user.displayAvatarURL({ extension: "png", size: 256 }),
    });
  }

  if (settings.thumbnailUrl) {
    embed.setThumbnail(settings.thumbnailUrl);
  } else if (settings.thumbnail) {
    embed.setThumbnail(member.user.displayAvatarURL({ extension: "png", size: 512 }));
  }

  if (settings.image) {
    embed.setImage(settings.image);
  }

  if (settings.footer) {
    embed.setFooter({
      text: parsePlaceholders(settings.footer, member),
      iconURL: member.guild.iconURL({ extension: "png" }) || undefined,
    });
  } else {
    embed.setFooter({
      text: `${member.guild.name}`,
      iconURL: member.guild.iconURL({ extension: "png" }) || undefined,
    });
  }

  return embed;
}

/**
 * Builds an ActionRow of link buttons from a guild's welcome settings.
 * settings.buttons is an array of up to 5 { label, url, emoji? } objects.
 * Returns null if there are no valid buttons configured.
 */
function buildWelcomeButtons(settings) {
  const buttons = Array.isArray(settings?.buttons) ? settings.buttons : [];
  if (buttons.length === 0) return null;

  const row = new ActionRowBuilder();

  for (const btn of buttons.slice(0, 5)) {
    if (!btn?.url || !btn?.label) continue;

    const button = new ButtonBuilder()
      .setLabel(btn.label.slice(0, 80))
      .setStyle(ButtonStyle.Link)
      .setURL(btn.url);

    if (btn.emoji) {
      try {
        button.setEmoji(btn.emoji);
      } catch {
        // Invalid emoji format, skip silently
      }
    }

    row.addComponents(button);
  }

  return row.components.length > 0 ? row : null;
}

module.exports = { parsePlaceholders, buildWelcomeEmbed, buildWelcomeButtons, ordinal };
