const { PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');

const ACTION_LABELS = {
    channelDelete: 'Channel Delete',
    channelCreate: 'Channel Create',
    roleDelete: 'Role Delete',
    roleCreate: 'Role Create',
    massBan: 'Mass Ban',
    massKick: 'Mass Kick',
    webhookCreate: 'Webhook Create',
    botAdd: 'Unauthorized Bot Add'
};

// Actions that support an instant "reverse" (undo the damage), separate
// from the threshold-based punishment of the executor.
const REVERT_LABELS = {
    channelCreate: 'Undo Channel Create (remove it)',
    channelDelete: 'Undo Channel Delete (recreate it)',
    massBan: 'Undo Ban (unban the member)',
    botAdd: 'Remove Unauthorized Bot (ban it)'
};

const PROTECTION_ROLE_NAME = 'Zyvora Protection';

const REQUIRED_PERMISSIONS = [
    { flag: PermissionFlagsBits.BanMembers, label: 'Ban Members' },
    { flag: PermissionFlagsBits.ViewAuditLog, label: 'View Audit Log' },
    { flag: PermissionFlagsBits.ManageRoles, label: 'Manage Roles' },
    { flag: PermissionFlagsBits.ManageChannels, label: 'Manage Channels' }
];

class AntiNukeManager {
    constructor(client) {
        this.client = client;

        this.settingsCache = new Map();
        this.actionCache = new Map();
        this.punishLock = new Set();
        this.processedLogs = new Set();
        this.pendingEvents = new Map();
        this.batchTimers = new Map();

        // Instant path: Discord pushes audit log entries over the gateway the
        // moment they're created (guildAuditLogEntryCreate) — no REST call, no
        // polling. This is what makes detection match your websocket latency
        // instead of waiting on fetchAuditLogs round-trips.
        this.auditEntryCache = new Map(); // `${guildId}:${targetId}` -> { executorId, ts }
        this.pendingByTarget = new Map(); // `${guildId}:${targetId}` -> { event, timer }

        setInterval(() => this.cleanup(), 60000);
    }

    defaultSettings(guildId) {
        return {
            guildId,
            enabled: false,
            logChannel: null,
            whitelist: [],
            extraOwners: [],
            protectionRoleId: null,
            // When true, the offender is banned on the very first offense
            // instead of waiting for the threshold count below to be reached.
            quickBan: true,
            actions: {
                channelDelete: true,
                channelCreate: true,
                roleDelete: true,
                roleCreate: true,
                massBan: true,
                massKick: true,
                webhookCreate: true,
                botAdd: true
            },
            thresholds: {
                channelDelete: { count: 1, window: 10000 },
                channelCreate: { count: 3, window: 10000 },
                roleDelete: { count: 1, window: 10000 },
                roleCreate: { count: 3, window: 10000 },
                massBan: { count: 1, window: 10000 },
                massKick: { count: 1, window: 10000 },
                webhookCreate: { count: 1, window: 10000 },
                botAdd: { count: 1, window: 10000 }
            },
            // Instant undo behavior — independent of the threshold punishment above.
            revert: {
                channelCreate: true,
                channelDelete: true,
                massBan: true,
                botAdd: true
            }
        };
    }

    getSettings(guildId) {
        let settings = this.settingsCache.get(guildId);
        if (!settings) {
            const row = this.client.db.antinuke.get(guildId);
            const defaults = this.defaultSettings(guildId);
            settings = row
                ? {
                    ...defaults,
                    ...row,
                    actions: { ...defaults.actions, ...(row.actions || {}) },
                    thresholds: { ...defaults.thresholds, ...(row.thresholds || {}) },
                    revert: { ...defaults.revert, ...(row.revert || {}) }
                }
                : defaults;
            this.settingsCache.set(guildId, settings);
        }
        return settings;
    }

    updateSettings(guildId, data) {
        this.client.db.antinuke.set(guildId, data);
        this.settingsCache.delete(guildId);
        return this.getSettings(guildId);
    }

    isBypassed(userId, guild, settings) {
        if (!userId) return true;
        if (userId === this.client.user.id) return true;
        if (userId === guild.ownerId) return true;
        if (this.client.owners?.includes(userId)) return true;
        if (settings.extraOwners?.includes(userId)) return true;
        if (settings.whitelist?.includes(userId)) return true;
        return false;
    }

    canManage(userId, guild, settings) {
        if (userId === guild.ownerId) return true;
        if (this.client.owners?.includes(userId)) return true;
        if (settings.extraOwners?.includes(userId)) return true;
        return false;
    }

    // Finds the audit log entry for a target within a fetched log page, preferring
    // an exact target match and falling back to the newest same-type unprocessed
    // entry (Discord doesn't always link the target fast enough during a burst).
    matchExecutor(logs, targetId) {
        if (!logs) return null;
        const entries = [...logs.entries.values()];

        let entry = entries.find(e => {
            if (Date.now() - e.createdTimestamp > 20000) return false;
            if (this.processedLogs.has(e.id)) return false;
            if (targetId && e.target?.id && e.target.id !== targetId) return false;
            return true;
        });

        if (!entry && targetId) {
            entry = entries.find(e =>
                Date.now() - e.createdTimestamp <= 20000 &&
                !this.processedLogs.has(e.id)
            );
        }

        if (!entry) return null;
        this.processedLogs.add(entry.id);
        setTimeout(() => this.processedLogs.delete(entry.id), 30000);
        return entry.executor?.id || null;
    }

    // One shared fetch per audit-log type instead of one per event — this is
    // what actually matters during a mass-nuke burst: 20 channel creates used
    // to mean 20 parallel fetchAuditLogs calls (Discord rate-limits that hard
    // and most silently fail); now it's one call per type per batch window.
    async fetchLogsForTypes(guild, types) {
        const result = {};
        await Promise.all(types.map(async type => {
            result[type] = await guild.fetchAuditLogs({ type, limit: 100 }).catch(() => null);
        }));
        return result;
    }

    trackAction(guildId, userId, actionType, threshold) {
        const key = `${guildId}:${userId}:${actionType}`;
        const now = Date.now();
        let arr = this.actionCache.get(key) || [];
        arr = arr.filter(ts => now - ts < threshold.window);
        arr.push(now);
        this.actionCache.set(key, arr);
        return arr.length;
    }

    // Called by the guildAuditLogEntryCreate gateway event the instant Discord
    // creates an audit log entry — no REST call involved, so this arrives at
    // roughly your gateway latency (the same ~15-30ms as any other event).
    onAuditLogEntry(guild, entry) {
        const targetId = entry?.targetId;
        const executorId = entry?.executorId;
        if (!targetId || !executorId) return;

        const key = `${guild.id}:${targetId}`;
        this.auditEntryCache.set(key, { executorId, ts: Date.now() });
        setTimeout(() => this.auditEntryCache.delete(key), 8000);

        // Something is already waiting on this exact target — resolve it now
        // instead of waiting for the REST fallback timer to expire.
        const pending = this.pendingByTarget.get(key);
        if (pending) {
            this.pendingByTarget.delete(key);
            clearTimeout(pending.timer);
            this.dispatchEvent(pending.event, executorId).catch(err =>
                console.error('[AntiNuke] Dispatch error:', err.message)
            );
        }
    }

    // Entry point for every event file. Fast path: correlate against the
    // gateway-pushed audit log entry (instant, no REST). If it hasn't arrived
    // yet (the two gateway events aren't guaranteed to arrive in a fixed order),
    // wait a very short moment for it before falling back to REST polling.
    async handle(guild, actionType, auditType, targetId = null, executorIdOverride = null, payload = null) {
        try {
            if (!guild) return;
            const settings = this.getSettings(guild.id);
            if (!settings.enabled) return;
            if (!settings.actions?.[actionType]) return;

            const event = { guild, actionType, auditType, targetId, payload };

            if (executorIdOverride) {
                return this.dispatchEvent(event, executorIdOverride);
            }

            if (!targetId) {
                return this.queueRestFallback(event);
            }

            const key = `${guild.id}:${targetId}`;
            const cached = this.auditEntryCache.get(key);
            if (cached) {
                this.auditEntryCache.delete(key);
                return this.dispatchEvent(event, cached.executorId);
            }

            // Give the gateway audit-log push a brief moment to arrive before
            // falling back to the slower, retry-backed REST path.
            const timer = setTimeout(() => {
                this.pendingByTarget.delete(key);
                this.queueRestFallback(event);
            }, 250);
            this.pendingByTarget.set(key, { event, timer });
        } catch (err) {
            console.error(`[AntiNuke] Error handling ${actionType}:`, err.message);
        }
    }

    async dispatchEvent(event, executorId) {
        const { guild } = event;
        const settings = this.getSettings(guild.id);
        if (this.isBypassed(executorId, guild, settings)) return;

        if (settings.revert?.[event.actionType] && event.payload) {
            this.revert(guild, event.actionType, event.payload, settings).catch(err =>
                console.error(`[AntiNuke] Revert error for ${event.actionType}:`, err.message)
            );
        }

        const threshold = settings.thresholds?.[event.actionType] || { count: 3, window: 10000 };
        const count = this.trackAction(guild.id, executorId, event.actionType, threshold);

        if (settings.quickBan || count >= threshold.count) {
            await this.punish(guild, executorId, event.actionType, settings);
        }
    }

    // Safety net for the rare case the gateway audit-log push doesn't show up
    // (e.g. brief Discord-side delay) — same debounced batch + backoff-retry
    // REST lookup as before, just demoted from primary path to fallback.
    queueRestFallback(event) {
        const guildId = event.guild.id;
        const list = this.pendingEvents.get(guildId) || [];
        list.push(event);
        this.pendingEvents.set(guildId, list);

        const existing = this.batchTimers.get(guildId);
        if (existing) clearTimeout(existing.timer);

        const firstSeenAt = existing?.firstSeenAt || Date.now();
        const elapsed = Date.now() - firstSeenAt;
        const delay = elapsed >= 1500 ? 0 : 350;

        const timer = setTimeout(() => {
            this.batchTimers.delete(guildId);
            this.processBatch(guildId).catch(err =>
                console.error('[AntiNuke] Batch processing error:', err.message)
            );
        }, delay);
        this.batchTimers.set(guildId, { timer, firstSeenAt });
    }

    async processBatch(guildId) {
        const events = this.pendingEvents.get(guildId) || [];
        this.pendingEvents.delete(guildId);
        if (!events.length) return;

        const guild = events[0].guild;
        const settings = this.getSettings(guildId);
        if (!settings.enabled) return;

        const me = guild.members.me;
        const canViewLogs = !!me?.permissions.has(PermissionFlagsBits.ViewAuditLog);

        if (!canViewLogs) return;

        const types = [...new Set(events.map(e => e.auditType))];
        const logsByType = await this.fetchLogsForTypes(guild, types);

        const unresolved = [];

        await Promise.all(events.map(async (event) => {
            const executorId = this.matchExecutor(logsByType[event.auditType], event.targetId);
            if (!executorId) {
                unresolved.push(event);
                return;
            }
            await this.dispatchEvent(event, executorId);
        }));

        if (!unresolved.length) return;

        const stillUnresolved = await this.resolveWithRetries(guild, unresolved);
        if (stillUnresolved.length) {
            this.logUnresolved(guild, settings, stillUnresolved).catch(() => null);
        }
    }

    // Audit log entries can lag well behind the gateway event during a heavy
    // burst (Discord's own backend is busy processing the same flood). Multiple
    // backoff attempts give it real time to catch up before we give up on an event.
    async resolveWithRetries(guild, events) {
        let remaining = events;
        const delays = [700, 1200, 2000];

        for (const delay of delays) {
            if (!remaining.length) break;
            await new Promise(res => setTimeout(res, delay));

            const types = [...new Set(remaining.map(e => e.auditType))];
            const logs = await this.fetchLogsForTypes(guild, types);
            const stillUnresolved = [];

            await Promise.all(remaining.map(async (event) => {
                const executorId = this.matchExecutor(logs[event.auditType], event.targetId);
                if (!executorId) {
                    stillUnresolved.push(event);
                    return;
                }
                await this.dispatchEvent(event, executorId);
            }));

            remaining = stillUnresolved;
        }

        return remaining;
    }

    async logUnresolved(guild, settings, events) {
        if (!settings.logChannel) return;

        let channel = guild.channels.cache.get(settings.logChannel);
        if (!channel) channel = await guild.channels.fetch(settings.logChannel).catch(() => null);
        if (!channel) return;

        const emoji = this.client.emoji;
        const counts = {};
        for (const e of events) counts[e.actionType] = (counts[e.actionType] || 0) + 1;
        const summary = Object.entries(counts).map(([type, n]) => `${ACTION_LABELS[type] || type} x${n}`).join(', ');

        const info = new TextDisplayBuilder().setContent(
            `### ${emoji.warn} AntiNuke Couldn't Confirm Executor\n` +
            `> ${emoji.dot} Detected: ${summary}\n` +
            `> ${emoji.dot} Discord's audit log never linked an executor in time, so no auto-revert or ban was taken for ${events.length === 1 ? 'this event' : 'these events'}.\n` +
            `> ${emoji.dot} Check the Audit Log manually if this looks suspicious.`
        );

        const container = new ContainerBuilder().setAccentColor(0xFFD700)
            .addTextDisplayComponents(info);

        channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => null);
    }

    // Instantly undoes the damage caused by a protected action, independent
    // of whether the executor also crosses the punishment threshold.
    async revert(guild, actionType, payload, settings) {
        const me = guild.members.me;
        let success = false;
        let reason = null;

        try {
            switch (actionType) {
                case 'channelCreate': {
                    if (!me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
                        reason = 'Missing Manage Channels permission';
                        break;
                    }
                    const channel = payload;
                    if (channel?.deletable) {
                        await channel.delete('AntiNuke: reverting unauthorized channel creation');
                        success = true;
                    }
                    break;
                }

                case 'channelDelete': {
                    if (!me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
                        reason = 'Missing Manage Channels permission';
                        break;
                    }
                    const channel = payload;
                    if (!channel) break;

                    const overwrites = channel.permissionOverwrites?.cache
                        ? [...channel.permissionOverwrites.cache.values()].map(o => ({
                            id: o.id,
                            type: o.type,
                            allow: o.allow,
                            deny: o.deny
                        }))
                        : [];

                    const options = {
                        name: channel.name,
                        type: channel.type,
                        parent: channel.parentId || null,
                        position: channel.rawPosition ?? channel.position,
                        permissionOverwrites: overwrites,
                        reason: 'AntiNuke: recreating unauthorized channel deletion'
                    };

                    if (typeof channel.topic === 'string') options.topic = channel.topic;
                    if (typeof channel.nsfw === 'boolean') options.nsfw = channel.nsfw;
                    if (typeof channel.bitrate === 'number') options.bitrate = channel.bitrate;
                    if (typeof channel.userLimit === 'number') options.userLimit = channel.userLimit;
                    if (typeof channel.rateLimitPerUser === 'number') options.rateLimitPerUser = channel.rateLimitPerUser;

                    await guild.channels.create(options);
                    success = true;
                    break;
                }

                case 'massBan': {
                    if (!me?.permissions.has(PermissionFlagsBits.BanMembers)) {
                        reason = 'Missing Ban Members permission';
                        break;
                    }
                    const userId = payload?.user?.id || payload?.id;
                    if (!userId) break;
                    await guild.members.unban(userId, 'AntiNuke: reverting unauthorized ban').catch(() => null);
                    success = true;
                    break;
                }

                case 'botAdd': {
                    if (!me?.permissions.has(PermissionFlagsBits.BanMembers)) {
                        reason = 'Missing Ban Members permission';
                        break;
                    }
                    const botMember = payload;
                    const botId = botMember?.id || botMember?.user?.id;
                    if (!botId) break;
                    if (botMember?.bannable === false) {
                        reason = 'Bot role is above mine — can\'t remove it';
                        break;
                    }
                    await guild.members.ban(botId, { reason: 'AntiNuke: removing unauthorized bot' }).catch(() => null);
                    success = true;
                    break;
                }

                default:
                    return;
            }
        } catch (err) {
            reason = err.message;
            console.error(`[AntiNuke] Revert failed for ${actionType}:`, err.message);
        }

        this.logRevert(guild, settings, actionType, success, reason).catch(() => null);
    }

    async punish(guild, executorId, actionType, settings) {
        const lockKey = `${guild.id}:${executorId}`;
        if (this.punishLock.has(lockKey)) return;
        this.punishLock.add(lockKey);
        setTimeout(() => this.punishLock.delete(lockKey), 15000);

        const reason = `AntiNuke: Triggered ${ACTION_LABELS[actionType] || actionType} protection`;
        let success = false;

        try {
            const member = await guild.members.fetch(executorId).catch(() => null);
            if (member) {
                if (member.bannable) {
                    await member.ban({ reason });
                    success = true;
                }
            } else {
                await guild.members.ban(executorId, { reason }).catch(() => null);
                success = true;
            }
        } catch (err) {
            console.error('[AntiNuke] Punish error:', err.message);
        }

        this.log(guild, settings, actionType, executorId, success).catch(() => null);
    }

    async log(guild, settings, actionType, executorId, success) {
        if (!settings.logChannel) return;

        let channel = guild.channels.cache.get(settings.logChannel);
        if (!channel) channel = await guild.channels.fetch(settings.logChannel).catch(() => null);
        if (!channel) return;

        const emoji = this.client.emoji;

        const info = new TextDisplayBuilder().setContent(
            `### ${emoji.cross} AntiNuke Triggered\n` +
            `> ${emoji.dot} **Action:** ${ACTION_LABELS[actionType] || actionType}\n` +
            `> ${emoji.dot} **User:** <@${executorId}> (\`${executorId}\`)\n` +
            `> ${emoji.dot} **Punishment:** ${success ? 'Banned' : `${emoji.warn} Failed to ban — check my role position/permissions`}`
        );

        const container = new ContainerBuilder().setAccentColor(0xFFD700)
            .addTextDisplayComponents(info);

        channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => null);
    }

    async logRevert(guild, settings, actionType, success, reason) {
        if (!settings.logChannel) return;

        let channel = guild.channels.cache.get(settings.logChannel);
        if (!channel) channel = await guild.channels.fetch(settings.logChannel).catch(() => null);
        if (!channel) return;

        const emoji = this.client.emoji;
        const label = REVERT_LABELS[actionType] || actionType;

        const info = new TextDisplayBuilder().setContent(
            `### ${emoji.info} AntiNuke Auto-Revert\n` +
            `> ${emoji.dot} **Action:** ${label}\n` +
            `> ${emoji.dot} **Result:** ${success ? `${emoji.check} Reverted successfully` : `${emoji.warn} Failed to revert${reason ? ` — ${reason}` : ''}`}`
        );

        const container = new ContainerBuilder().setAccentColor(success ? 0xFFD700 : 0xFFD700)
            .addTextDisplayComponents(info);

        channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => null);
    }

    // Checks the bot's guild-wide permissions needed for AntiNuke to work fully.
    getMissingPermissions(guild) {
        const me = guild.members.me;
        if (!me) return REQUIRED_PERMISSIONS.map(p => p.label);
        return REQUIRED_PERMISSIONS.filter(p => !me.permissions.has(p.flag)).map(p => p.label);
    }

    // Creates (or re-finds) the "Zyvora Protection" role and pushes it as
    // high in the hierarchy as the bot is able to, then assigns it to itself.
    async ensureProtectionRole(guild) {
        const me = guild.members.me;
        if (!me?.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return { role: null, error: 'Missing Manage Roles permission' };
        }

        const settings = this.getSettings(guild.id);
        let role = settings.protectionRoleId
            ? guild.roles.cache.get(settings.protectionRoleId)
            : null;

        if (!role) {
            role = guild.roles.cache.find(r => r.name === PROTECTION_ROLE_NAME) || null;
        }

        if (!role) {
            try {
                role = await guild.roles.create({
                    name: PROTECTION_ROLE_NAME,
                    color: 0xFFD700,
                    hoist: false,
                    mentionable: false,
                    permissions: [],
                    reason: 'AntiNuke: creating protection indicator role'
                });
            } catch (err) {
                return { role: null, error: err.message };
            }
        }

        try {
            const highestManageable = me.roles.highest.position - 1;
            if (highestManageable > 0 && role.position < highestManageable && role.editable) {
                await role.setPosition(highestManageable);
            }
        } catch {
            // Non-fatal — role still exists even if we couldn't move it to the very top.
        }

        if (!me.roles.cache.has(role.id)) {
            await me.roles.add(role).catch(() => null);
        }

        this.updateSettings(guild.id, { ...settings, protectionRoleId: role.id });
        return { role, error: null };
    }

    cleanup() {
        const now = Date.now();
        for (const [key, arr] of this.actionCache.entries()) {
            if (!Array.isArray(arr) || arr.every(ts => now - ts > 120000)) {
                this.actionCache.delete(key);
            }
        }
    }
}

module.exports = AntiNukeManager;
