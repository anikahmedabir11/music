const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');

const MAX_PER_GUILD = 50;
const REPLY_COOLDOWN_MS = 3000; // per trigger, per channel — stops rapid-fire spam

function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Applies {user}/{server}/{channel}/{mention} placeholders to a response string.
 */
function applyPlaceholders(text, message) {
    return text
        .replace(/\{user\.mention\}|\{mention\}/gi, `${message.author}`)
        .replace(/\{user\.tag\}/gi, message.author.tag || message.author.username)
        .replace(/\{user\}/gi, message.author.username)
        .replace(/\{server\}/gi, message.guild.name)
        .replace(/\{channel\}/gi, `${message.channel}`);
}

class AutoresponderManager {
    constructor(client) {
        this.client = client;
        // guildId -> array of responder rows (cached to avoid a DB hit on every message)
        this.cache = new Map();
        // `${guildId}:${channelId}:${id}` -> last-fired timestamp
        this.cooldowns = new Map();

        setInterval(() => this.cleanupCooldowns(), 60000);
    }

    cleanupCooldowns() {
        const now = Date.now();
        for (const [key, ts] of this.cooldowns) {
            if (now - ts > REPLY_COOLDOWN_MS) this.cooldowns.delete(key);
        }
    }

    async getAll(guildId) {
        let list = this.cache.get(guildId);
        if (!list) {
            list = await this.client.db.autoresponders.getForGuild(guildId);
            this.cache.set(guildId, list);
        }
        return list;
    }

    invalidate(guildId) {
        this.cache.delete(guildId);
    }

    async countActive(guildId) {
        const list = await this.getAll(guildId);
        return list.length;
    }

    async maxReached(guildId) {
        return (await this.countActive(guildId)) >= MAX_PER_GUILD;
    }

    /**
     * Finds the single best match for a message's content among a guild's
     * configured triggers. Matching is intentionally strict so the bot only
     * fires when someone has *actually* said the trigger, not whenever the
     * trigger word merely shows up as a fragment of unrelated text:
     *   - exact       -> the whole message must equal the trigger
     *   - startswith  -> the message must start with the trigger as a whole word
     *   - contains    -> the trigger must appear as a whole word/phrase anywhere
     * When multiple triggers could match, the most specific one wins:
     * exact > startswith > contains, and — within the same type — the longest
     * (most specific) trigger text wins.
     */
    async findMatch(guildId, content) {
        const list = await this.getAll(guildId);
        const responders = list.filter(r => r.enabled);
        if (!responders.length) return null;

        const raw = content.trim();
        if (!raw) return null;

        const rank = { exact: 3, startswith: 2, contains: 1 };
        let best = null;

        for (const r of responders) {
            const flags = r.caseSensitive ? '' : 'i';
            const trigger = r.trigger.trim();
            if (!trigger) continue;

            const target = r.caseSensitive ? raw : raw.toLowerCase();
            const compareTrigger = r.caseSensitive ? trigger : trigger.toLowerCase();

            let matched = false;
            const type = r.matchType || 'exact';

            if (type === 'exact') {
                matched = target === compareTrigger;
            } else if (type === 'startswith') {
                const re = new RegExp(`^${escapeRegex(trigger)}(\\s|$)`, flags);
                matched = re.test(raw);
            } else if (type === 'contains') {
                const re = new RegExp(`(^|\\s)${escapeRegex(trigger)}(\\s|$)`, flags);
                matched = re.test(raw);
            }

            if (!matched) continue;

            const score = rank[type] || 0;
            if (!best || score > best.score || (score === best.score && trigger.length > best.trigger.length)) {
                best = { ...r, score };
            }
        }

        return best;
    }

    async handleMessage(message) {
        if (!message.guild || message.author.bot) return;

        const match = await this.findMatch(message.guild.id, message.content);
        if (!match) return;

        const cooldownKey = `${message.guild.id}:${message.channel.id}:${match.id}`;
        const lastFired = this.cooldowns.get(cooldownKey);
        if (lastFired && Date.now() - lastFired < REPLY_COOLDOWN_MS) return;

        const perms = message.channel.permissionsFor(this.client.user);
        if (!perms || !perms.has('SendMessages')) return;

        this.cooldowns.set(cooldownKey, Date.now());

        const text = applyPlaceholders(match.response, message);

        try {
            if (perms.has('EmbedLinks')) {
                const display = new TextDisplayBuilder().setContent(text);
                const container = new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(display);
                await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => { });
            } else {
                await message.reply({ content: text }).catch(() => { });
            }
        } catch (err) {
            console.error(`[Autoresponder Error] ${err.message}`);
        }
    }
}

module.exports = AutoresponderManager;
