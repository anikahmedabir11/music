const {
    MessageFlags,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ChannelType
} = require('discord.js');
const emoji = require('../../emojis');

const ACTION_LABELS = {
    channelDelete: 'Channel Delete',
    channelCreate: 'Channel Create',
    roleDelete: 'Role Delete',
    roleCreate: 'Role Create',
    massBan: 'Mass Ban',
    massKick: 'Mass Kick',
    webhookCreate: 'Webhook Create',
    botAdd: 'Unauthorized Bot Add'
};

const REVERT_LABELS = {
    channelCreate: 'Channel Create → auto-remove',
    channelDelete: 'Channel Delete → auto-recreate',
    massBan: 'Ban → auto-unban',
    botAdd: 'Unauthorized Bot Add → auto-ban the bot'
};

function box(color, content) {
    const display = new TextDisplayBuilder().setContent(content);
    return { components: [new ContainerBuilder().setAccentColor(color).addTextDisplayComponents(display)], flags: MessageFlags.IsComponentsV2 };
}

async function resolveUserId(message, arg, client) {
    if (!arg) return null;
    const mentionMatch = arg.match(/^<@!?(\d+)>$/);
    if (mentionMatch) return mentionMatch[1];
    if (/^\d{15,25}$/.test(arg)) {
        const user = await client.users.fetch(arg).catch(() => null);
        return user ? user.id : null;
    }
    return null;
}

module.exports = {
    name: 'antinuke',
    description: 'Configure AntiNuke protection for this server.',
    category: 'Antinuke',
    aliases: ['an'],
    usage: 'antinuke <subcommand> [args]',
    example: 'antinuke enable | antinuke whitelist add @user | antinuke status',
    subCommands: ['enable', 'disable', 'status', 'log', 'whitelist', 'owner', 'action', 'revert', 'quickban', 'threshold', 'reset'],
    slashOptions: [
        { name: 'enable', description: 'Enable AntiNuke protection', type: 1 },
        { name: 'disable', description: 'Disable AntiNuke protection', type: 1 },
        { name: 'status', description: 'View current AntiNuke configuration', type: 1 },
        {
            name: 'log', description: 'Set the AntiNuke log channel', type: 1,
            options: [{ name: 'channel', description: 'The channel to log AntiNuke actions to', type: 7, required: true }]
        },
        {
            name: 'whitelist', description: 'Manage whitelisted users (bypass AntiNuke)', type: 1,
            options: [
                { name: 'action', description: 'add / remove / list', type: 3, required: true },
                { name: 'user', description: 'The user to add/remove', type: 6, required: false }
            ]
        },
        {
            name: 'owner', description: 'Manage extra owners (bypass + can manage AntiNuke)', type: 1,
            options: [
                { name: 'action', description: 'add / remove / list', type: 3, required: true },
                { name: 'user', description: 'The user to add/remove', type: 6, required: false }
            ]
        },
        {
            name: 'action', description: 'Toggle a specific protected action on/off', type: 1,
            options: [
                { name: 'name', description: 'channelDelete, channelCreate, roleDelete, roleCreate, massBan, massKick, webhookCreate, botAdd', type: 3, required: true },
                { name: 'state', description: 'on / off', type: 3, required: true }
            ]
        },
        {
            name: 'revert', description: 'Toggle instant auto-revert (undo the damage) for an action', type: 1,
            options: [
                { name: 'name', description: 'channelCreate, channelDelete, massBan, botAdd', type: 3, required: true },
                { name: 'state', description: 'on / off', type: 3, required: true }
            ]
        },
        {
            name: 'quickban', description: 'Ban offenders instantly on first offense instead of waiting for threshold', type: 1,
            options: [{ name: 'state', description: 'on / off', type: 3, required: true }]
        },
        {
            name: 'threshold', description: 'Set how many occurrences within a time window trigger a ban', type: 1,
            options: [
                { name: 'name', description: 'channelDelete, channelCreate, roleDelete, roleCreate, massBan, massKick, webhookCreate, botAdd', type: 3, required: true },
                { name: 'count', description: 'Number of occurrences before punishing', type: 4, required: true },
                { name: 'seconds', description: 'Time window in seconds (default 10)', type: 4, required: false }
            ]
        },
        { name: 'reset', description: 'Reset AntiNuke settings to default', type: 1 }
    ],

    async slashExecute(interaction, client) {
        const interactionWrapper = {
            guild: interaction.guild,
            channel: interaction.channel,
            author: interaction.user,
            member: interaction.member,
            mentions: { users: new Map(), members: new Map() },
            reply: async (options) => {
                if (interaction.deferred) return await interaction.editReply(options);
                if (interaction.replied) return await interaction.followUp(options);
                return await interaction.reply(options);
            }
        };

        const sub = interaction.options.getSubcommand();
        const args = [sub];

        if (sub === 'log') {
            const channel = interaction.options.getChannel('channel');
            args.push(channel.id);
        } else if (sub === 'whitelist' || sub === 'owner') {
            args.push(interaction.options.getString('action'));
            const user = interaction.options.getUser('user');
            if (user) args.push(`<@${user.id}>`);
        } else if (sub === 'action' || sub === 'revert') {
            args.push(interaction.options.getString('name'));
            args.push(interaction.options.getString('state'));
        } else if (sub === 'quickban') {
            args.push(interaction.options.getString('state'));
        } else if (sub === 'threshold') {
            args.push(interaction.options.getString('name'));
            args.push(String(interaction.options.getInteger('count')));
            const seconds = interaction.options.getInteger('seconds');
            if (seconds) args.push(String(seconds));
        }

        return this.execute(interactionWrapper, args, client);
    },

    async execute(message, args, client) {
        if (!message.guild) return;

        const antinuke = client.antinuke;
        if (!antinuke) {
            return message.reply(box(0xFFD700, `${emoji.cross} AntiNuke module failed to initialize. Check the bot logs.`));
        }

        const settings = antinuke.getSettings(message.guild.id);
        const userId = message.author.id;

        if (!antinuke.canManage(userId, message.guild, settings)) {
            return message.reply(box(0xFFD700, `${emoji.warn} Only the server owner or an AntiNuke owner can manage this.`));
        }

        const subcommand = (args[0] || '').toLowerCase();

        switch (subcommand) {
            case 'enable': {
                antinuke.updateSettings(message.guild.id, { ...settings, enabled: true });

                const missingPerms = antinuke.getMissingPermissions(message.guild);
                const { role, error: roleError } = await antinuke.ensureProtectionRole(message.guild);

                let roleLine;
                if (role) {
                    roleLine = `> ${emoji.dot} **Protection Role:** ${role} created and moved as high as I could put it.`;
                } else {
                    roleLine = `> ${emoji.dot} **Protection Role:** ${emoji.warn} Missing perms — couldn't create/move \`AxC Protection\`${roleError ? ` (${roleError})` : ''}.`;
                }

                const permsLine = missingPerms.length
                    ? `> ${emoji.dot} ${emoji.warn} **Missing Perms:** ${missingPerms.join(', ')} — AntiNuke won't fully work until these are granted.`
                    : `> ${emoji.dot} ${emoji.check} I have all the permissions I need.`;

                return message.reply(box(0xFFD700,
                    `### ${emoji.check} AntiNuke Enabled\n` +
                    `> ${emoji.dot} Your server is now protected against channel/role wipes, mass bans/kicks, rogue webhooks & unauthorized bot adds.\n` +
                    `> ${emoji.dot} Unauthorized channel creates/deletes and bans will also be **auto-reverted** instantly (see \`antinuke revert\`).\n` +
                    `> ${emoji.dot} **Quick Ban** is ${settings.quickBan !== false ? 'ON' : 'OFF'} — offenders get banned on their first offense${settings.quickBan !== false ? '' : ' (toggle with `antinuke quickban on`)'}.\n` +
                    `${roleLine}\n` +
                    `${permsLine}`
                ));
            }

            case 'disable': {
                antinuke.updateSettings(message.guild.id, { ...settings, enabled: false });
                return message.reply(box(0xFFD700, `${emoji.warn} AntiNuke has been disabled for this server.`));
            }

            case 'status': {
                const actionLines = Object.entries(settings.actions || {})
                    .map(([key, on]) => `> ${emoji.dot} **${ACTION_LABELS[key] || key}:** ${on ? emoji.check : emoji.cross}`)
                    .join('\n');

                const header = new TextDisplayBuilder()
                    .setContent(`### ${emoji.info} AntiNuke Status\n-# ${message.guild.name}`);

                const revertLines = Object.entries(REVERT_LABELS)
                    .map(([key, label]) => `> ${emoji.dot} **${label}:** ${settings.revert?.[key] ? emoji.check : emoji.cross}`)
                    .join('\n');

                const missingPerms = antinuke.getMissingPermissions(message.guild);
                const protectionRole = settings.protectionRoleId ? message.guild.roles.cache.get(settings.protectionRoleId) : null;

                const info = new TextDisplayBuilder()
                    .setContent(
                        `> ${emoji.dot} **Enabled:** ${settings.enabled ? emoji.check : emoji.cross}\n` +
                        `> ${emoji.dot} **Quick Ban:** ${settings.quickBan ? `${emoji.check} Bans on first offense` : `${emoji.cross} Waits for threshold`}\n` +
                        `> ${emoji.dot} **Protection Role:** ${protectionRole ? protectionRole : 'Not created yet'}\n` +
                        `> ${emoji.dot} **Log Channel:** ${settings.logChannel ? `<#${settings.logChannel}>` : 'Not set'}\n` +
                        `> ${emoji.dot} **Whitelist:** ${settings.whitelist?.length ? settings.whitelist.map(id => `<@${id}>`).join(', ') : 'None'}\n` +
                        `> ${emoji.dot} **Extra Owners:** ${settings.extraOwners?.length ? settings.extraOwners.map(id => `<@${id}>`).join(', ') : 'None'}\n` +
                        `> ${emoji.dot} **Bot Perms:** ${missingPerms.length ? `${emoji.warn} Missing: ${missingPerms.join(', ')}` : `${emoji.check} All granted`}`
                    );

                const actionsDisplay = new TextDisplayBuilder().setContent(`**Protected Actions**\n${actionLines}`);
                const revertDisplay = new TextDisplayBuilder().setContent(`**Auto-Revert (Instant Undo)**\n${revertLines}`);

                const container = new ContainerBuilder().setAccentColor(0xFFD700)
                    .addTextDisplayComponents(header)
                    .addSeparatorComponents(new SeparatorBuilder())
                    .addTextDisplayComponents(info)
                    .addSeparatorComponents(new SeparatorBuilder())
                    .addTextDisplayComponents(actionsDisplay)
                    .addSeparatorComponents(new SeparatorBuilder())
                    .addTextDisplayComponents(revertDisplay);

                return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            case 'log': {
                const channelArg = args[1];
                const channelId = channelArg?.replace(/[<#>]/g, '');
                const channel = message.guild.channels.cache.get(channelId);

                if (!channel || channel.type !== ChannelType.GuildText) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Please provide a valid text channel.`));
                }

                antinuke.updateSettings(message.guild.id, { ...settings, logChannel: channel.id });
                return message.reply(box(0xFFD700, `${emoji.check} AntiNuke log channel set to ${channel}.`));
            }

            case 'whitelist':
            case 'owner': {
                const listKey = subcommand === 'whitelist' ? 'whitelist' : 'extraOwners';
                const label = subcommand === 'whitelist' ? 'Whitelist' : 'Extra Owners';
                const action = (args[1] || '').toLowerCase();
                const list = [...(settings[listKey] || [])];

                if (action === 'list') {
                    return message.reply(box(0xFFD700,
                        `### ${emoji.info} ${label}\n` +
                        (list.length ? list.map(id => `> ${emoji.dot} <@${id}>`).join('\n') : `> ${emoji.dot} Nobody added yet.`)
                    ));
                }

                if (action === 'add' || action === 'remove') {
                    const targetId = await resolveUserId(message, args[2], client);
                    if (!targetId) {
                        return message.reply(box(0xFFD700, `${emoji.warn} Please mention a valid user. Usage: \`antinuke ${subcommand} ${action} @user\``));
                    }

                    if (action === 'add') {
                        if (list.includes(targetId)) {
                            return message.reply(box(0xFFD700, `${emoji.warn} <@${targetId}> is already in the ${label.toLowerCase()}.`));
                        }
                        list.push(targetId);
                    } else {
                        if (!list.includes(targetId)) {
                            return message.reply(box(0xFFD700, `${emoji.warn} <@${targetId}> isn't in the ${label.toLowerCase()}.`));
                        }
                        const idx = list.indexOf(targetId);
                        list.splice(idx, 1);
                    }

                    antinuke.updateSettings(message.guild.id, { ...settings, [listKey]: list });
                    return message.reply(box(0xFFD700, `${emoji.check} <@${targetId}> has been ${action === 'add' ? 'added to' : 'removed from'} the ${label.toLowerCase()}.`));
                }

                return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`antinuke ${subcommand} <add|remove|list> [@user]\``));
            }

            case 'action': {
                const key = args[1];
                const state = (args[2] || '').toLowerCase();

                if (!key || !ACTION_LABELS[key]) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Valid actions: \`${Object.keys(ACTION_LABELS).join(', ')}\``));
                }
                if (!['on', 'off'].includes(state)) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`antinuke action ${key} <on|off>\``));
                }

                const actions = { ...settings.actions, [key]: state === 'on' };
                antinuke.updateSettings(message.guild.id, { ...settings, actions });
                return message.reply(box(0xFFD700, `${emoji.check} **${ACTION_LABELS[key]}** protection turned **${state.toUpperCase()}**.`));
            }

            case 'revert': {
                const key = args[1];
                const state = (args[2] || '').toLowerCase();

                if (!key || !REVERT_LABELS[key]) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Valid revert actions: \`${Object.keys(REVERT_LABELS).join(', ')}\``));
                }
                if (!['on', 'off'].includes(state)) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`antinuke revert ${key} <on|off>\``));
                }

                const revert = { ...settings.revert, [key]: state === 'on' };
                antinuke.updateSettings(message.guild.id, { ...settings, revert });
                return message.reply(box(0xFFD700, `${emoji.check} **${REVERT_LABELS[key]}** auto-revert turned **${state.toUpperCase()}**.`));
            }

            case 'quickban': {
                const state = (args[1] || '').toLowerCase();
                if (!['on', 'off'].includes(state)) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`antinuke quickban <on|off>\``));
                }

                antinuke.updateSettings(message.guild.id, { ...settings, quickBan: state === 'on' });
                return message.reply(box(0xFFD700,
                    state === 'on'
                        ? `${emoji.check} **Quick Ban** enabled — offenders will be banned on their **first** detected offense.`
                        : `${emoji.check} **Quick Ban** disabled — offenders will only be banned once they hit the configured threshold (see \`antinuke threshold\`).`
                ));
            }

            case 'threshold': {
                const key = args[1];
                const count = parseInt(args[2], 10);
                const seconds = args[3] ? parseInt(args[3], 10) : null;

                if (!key || !ACTION_LABELS[key]) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Valid actions: \`${Object.keys(ACTION_LABELS).join(', ')}\``));
                }
                if (!Number.isFinite(count) || count < 1) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`antinuke threshold ${key} <count> [seconds]\``));
                }

                const existing = settings.thresholds?.[key] || { count: 1, window: 10000 };
                const thresholds = {
                    ...settings.thresholds,
                    [key]: {
                        count,
                        window: seconds ? seconds * 1000 : existing.window
                    }
                };

                antinuke.updateSettings(message.guild.id, { ...settings, thresholds });
                return message.reply(box(0xFFD700,
                    `${emoji.check} **${ACTION_LABELS[key]}** will now trigger after **${count}** occurrence(s) within **${(thresholds[key].window / 1000)}s**.`
                ));
            }

            case 'reset': {
                const defaults = antinuke.defaultSettings(message.guild.id);
                antinuke.updateSettings(message.guild.id, defaults);
                return message.reply(box(0xFFD700, `${emoji.warn} AntiNuke settings have been reset to default.`));
            }

            default: {
                const helpDisplay = new TextDisplayBuilder()
                    .setContent(
                        `### ${emoji.info} AntiNuke Commands\n` +
                        `> ${emoji.dot} \`antinuke enable\` / \`disable\`\n` +
                        `> ${emoji.dot} \`antinuke status\`\n` +
                        `> ${emoji.dot} \`antinuke log #channel\`\n` +
                        `> ${emoji.dot} \`antinuke whitelist <add|remove|list> [@user]\`\n` +
                        `> ${emoji.dot} \`antinuke owner <add|remove|list> [@user]\`\n` +
                        `> ${emoji.dot} \`antinuke action <name> <on|off>\`\n` +
                        `> ${emoji.dot} \`antinuke revert <channelCreate|channelDelete|massBan|botAdd> <on|off>\`\n` +
                        `> ${emoji.dot} \`antinuke quickban <on|off>\`\n` +
                        `> ${emoji.dot} \`antinuke threshold <name> <count> [seconds]\`\n` +
                        `> ${emoji.dot} \`antinuke reset\`\n\n` +
                        `-# Enabling AntiNuke creates a \`AxC Protection\` role and, when auto-revert is on, ` +
                        `instantly undoes unauthorized channel creates/deletes & bans — on top of punishing the offender.`
                    );

                const container = new ContainerBuilder().setAccentColor(0xFFD700)
                    .addTextDisplayComponents(helpDisplay);

                return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        }
    }
};
