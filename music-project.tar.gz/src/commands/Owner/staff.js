const {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder
} = require("discord.js");

// Staff rank granted by this command. Must match a value in the
// `hierarchy` array inside src/utils/permissionCheck.js
const STAFF_RANK = "Staff";

module.exports = {
  name: "staff",
  aliases: ["stf"],
  category: "Owner",
  description: "Add, remove, or blacklist bot staff members.",
  args: false,
  usage: "add/remove/blacklist/list <user>",
  example: "staff add @user",
  owner: true, // only bot owners (config.ownerID) can manage staff

  slashOptions: [
    {
      name: "add",
      description: "Promote a user to Staff",
      type: 1,
      options: [
        { name: "user", description: "User to promote", type: 6, required: true }
      ]
    },
    {
      name: "remove",
      description: "Demote a Staff member back to User",
      type: 1,
      options: [
        { name: "user", description: "User to demote", type: 6, required: true }
      ]
    },
    {
      name: "blacklist",
      description: "Blacklist a user from using the bot",
      type: 1,
      options: [
        { name: "user", description: "User to blacklist", type: 6, required: true }
      ]
    },
    {
      name: "list",
      description: "List all current staff members",
      type: 1,
      options: []
    }
  ],

  async slashExecute(interaction, client) {
    if (!client.owners.includes(interaction.user.id)) return;

    const subcommand = interaction.options.getSubcommand();
    const user = interaction.options.getUser("user");

    const send = (content) =>
      interaction.reply({
        components: [new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(new TextDisplayBuilder().setContent(content))],
        flags: MessageFlags.IsComponentsV2
      });

    return handle(subcommand, user, client, interaction.user, send);
  },

  async execute(message, args, client, prefix) {
    if (!client.owners.includes(message.author.id)) return;

    const send = (content) =>
      message.reply({
        components: [new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(new TextDisplayBuilder().setContent(content))],
        flags: MessageFlags.IsComponentsV2
      });

    if (!args[0]) {
      const helpHeader = new TextDisplayBuilder()
        .setContent(`\`\`\`[] = Optional Argument\n<> = Required Argument\nDo NOT type these when using commands!)\`\`\``);
      const separator1 = new SeparatorBuilder();
      const aliasesDisplay = new TextDisplayBuilder().setContent(`**Aliases:** \`\`[stf]\`\``);
      const usageDisplay = new TextDisplayBuilder()
        .setContent(`**Usage:** \`\`${prefix}staff add/remove/blacklist/list [user]\`\``);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(helpHeader)
        .addSeparatorComponents(separator1)
        .addTextDisplayComponents(aliasesDisplay)
        .addTextDisplayComponents(usageDisplay);

      return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    const subcommand = args[0].toLowerCase();
    let user = null;

    if (subcommand !== "list") {
      user = message.mentions.users.first() || (await client.users.fetch(args[1] || "").catch(() => null));
      if (!user) return send(`**Provide me a valid user**`);
    }

    return handle(subcommand, user, client, message.author, send);
  }
};

async function handle(subcommand, user, client, executor, send) {
  if (subcommand === "add" || subcommand === "a" || subcommand === "+") {
    let profile = client.db.profiles.get(user.id);
    if (!profile) profile = { userId: user.id, badges: [], rank: "User" };

    if (profile.rank === STAFF_RANK) {
      return send(`**${client.emoji.info} ${user} is already Staff.**`);
    }

    profile.rank = STAFF_RANK;
    client.db.profiles.set(user.id, profile);

    // Auto-grant global no-prefix access to staff members
    client.db.noprefix.set(user.id, "GLOBAL", true);

    return send(`**${client.emoji.check} ${user} has been promoted to Staff and granted no-prefix access.**`);
  }

  if (subcommand === "remove" || subcommand === "r" || subcommand === "-") {
    const profile = client.db.profiles.get(user.id);

    if (!profile || profile.rank !== STAFF_RANK) {
      return send(`**${client.emoji.info} ${user} is not currently Staff.**`);
    }

    profile.rank = "User";
    client.db.profiles.set(user.id, profile);

    // Revoke the global no-prefix access granted on promotion
    client.db.noprefix.set(user.id, "GLOBAL", false);

    return send(`**${client.emoji.check} ${user} has been demoted from Staff and no-prefix access revoked.**`);
  }

  if (subcommand === "blacklist" || subcommand === "bl") {
    const existing = client.db.blacklist.get(user.id);
    if (existing) {
      return send(`**${client.emoji.info} ${user} is already blacklisted.**`);
    }

    client.db.blacklist.set(user.id, { developer: executor.id });
    return send(`**${client.emoji.check} ${user} has been blacklisted from using the bot.**`);
  }

  if (subcommand === "list") {
    // client.db.profiles only exposes get/set (no find/getAll), so query the raw db directly
    const staffProfiles = client.db.db.prepare("SELECT * FROM profiles WHERE rank = ?").all(STAFF_RANK);

    if (staffProfiles.length === 0) {
      return send(`**${client.emoji.info} There are no Staff members currently.**`);
    }

    const list = await Promise.all(
      staffProfiles.map(async (p) => {
        const u = await client.users.fetch(p.userId).catch(() => null);
        return u ? `**${u.tag}** (\`${u.id}\`)` : `Unknown User (\`${p.userId}\`)`;
      })
    );

    return send(`**${client.emoji.check} Staff Members**\n${list.join("\n")}`);
  }

  return send(`**${client.emoji.warn} Unknown subcommand. Use \`add\`, \`remove\`, \`blacklist\`, or \`list\`.**`);
}
