const {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    ChannelSelectMenuBuilder,
    RoleSelectMenuBuilder,
    ChannelType,
    PermissionFlagsBits,
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');
const emoji = require('../../emojis');

const DEFAULT_CATEGORIES = [
    { id: 'general', label: 'General Support', emoji: '🎫', description: 'General questions or help' },
    { id: 'billing', label: 'Billing', emoji: '💳', description: 'Payment and billing issues' },
    { id: 'bug', label: 'Bug Report', emoji: '🐛', description: 'Report a bug or technical issue' },
    { id: 'partnership', label: 'Partnership', emoji: '🤝', description: 'Business & partnership inquiries' },
    { id: 'other', label: 'Other', emoji: '❓', description: 'Anything that doesn\'t fit above' }
];

function box(content, color = 0xFFD700) {
    const display = new TextDisplayBuilder().setContent(content);
    return { components: [new ContainerBuilder().setAccentColor(color).addTextDisplayComponents(display)], flags: MessageFlags.IsComponentsV2 };
}

async function resolveUserId(client, arg) {
    if (!arg) return null;
    const mentionMatch = arg.match(/^<@!?(\d+)>$/);
    if (mentionMatch) return mentionMatch[1];
    if (/^\d{15,25}$/.test(arg)) {
        const user = await client.users.fetch(arg).catch(() => null);
        return user ? user.id : null;
    }
    return null;
}

function getConfig(client, guildId) {
    const row = client.db.ticketconfig.get(guildId);
    if (!row) {
        return { guildId, categoryId: null, logChannelId: null, supportRoleId: null, categories: DEFAULT_CATEGORIES, ticketCounter: 0 };
    }
    if (!row.categories || !row.categories.length) row.categories = DEFAULT_CATEGORIES;
    return row;
}

function isStaffMember(client, config, member) {
    if (!member) return false;
    if (client.owners.includes(member.id)) return true;
    if (member.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
    if (config.supportRoleId && member.roles.cache.has(config.supportRoleId)) return true;
    return false;
}

function renderTicketContainer(ticket) {
    const statusLine = ticket.status === 'closed'
        ? `**Status:** \`Closed\`${ticket.closedBy ? ` by <@${ticket.closedBy}>` : ''}`
        : '**Status:** `Open`';

    const content =
        `### 🎫 Ticket — ${ticket.categoryLabel || 'Support'}\n` +
        `${emoji.blank}${emoji.wickarrow} **Opened by:** <@${ticket.userId}>\n` +
        `${emoji.blank}${emoji.wickarrow} **Claimed by:** ${ticket.claimedBy ? `<@${ticket.claimedBy}>` : '`Not claimed`'}\n` +
        `${emoji.blank}${emoji.wickarrow} ${statusLine}\n\n` +
        `-# Use the buttons below to manage this ticket.`;

    const color = ticket.status === 'closed' ? 0xFFD700 : 0xFFD700;
    return new ContainerBuilder().setAccentColor(color).addTextDisplayComponents(new TextDisplayBuilder().setContent(content));
}

function renderTicketButtons(ticket) {
    if (ticket.status === 'closed') {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ticket_reopen').setLabel('Reopen').setStyle(ButtonStyle.Success).setEmoji('🔓'),
            new ButtonBuilder().setCustomId('ticket_delete').setLabel('Delete').setStyle(ButtonStyle.Danger).setEmoji('🗑️')
        );
    }

    return new ActionRowBuilder().addComponents(
        ticket.claimedBy
            ? new ButtonBuilder().setCustomId('ticket_unclaim').setLabel('Unclaim').setStyle(ButtonStyle.Secondary).setEmoji('🙌')
            : new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setStyle(ButtonStyle.Primary).setEmoji('✋'),
        new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒')
    );
}

async function updateTicketMessage(channel, ticket) {
    if (!ticket.messageId) return;
    try {
        const msg = await channel.messages.fetch(ticket.messageId);
        await msg.edit({
            components: [renderTicketContainer(ticket), renderTicketButtons(ticket)],
            flags: MessageFlags.IsComponentsV2
        });
    } catch (e) { /* message may have been deleted, ignore */ }
}

module.exports = {
    name: 'ticket',
    aliases: ['tickets'],
    category: 'Tickets',
    description: 'Set up and manage the server ticket system',
    usage: 'ticket <setup/panel/category/close/claim/unclaim/add/remove/list> [args]',
    example: 'ticket setup | ticket panel #support | ticket category add Suggestions',
    subCommands: ['setup', 'panel', 'category', 'close', 'claim', 'unclaim', 'add', 'remove', 'list'],
    botPerms: ['ManageChannels'],
    slashOptions: [
        { name: 'setup', description: 'Configure the ticket category, log channel and support role', type: 1 },
        {
            name: 'panel',
            description: 'Send the ticket-opening dropdown panel to a channel',
            type: 1,
            options: [
                { name: 'channel', description: 'Channel to send the panel in (defaults to current)', type: 7, required: false }
            ]
        },
        {
            name: 'category',
            description: 'Manage the categories shown in the ticket dropdown',
            type: 1,
            options: [
                { name: 'action', description: 'add / remove / list', type: 3, required: true },
                { name: 'name', description: 'Category name (for add/remove)', type: 3, required: false },
                { name: 'emoji', description: 'Emoji for the category (for add)', type: 3, required: false },
                { name: 'description', description: 'Short description (for add)', type: 3, required: false }
            ]
        },
        {
            name: 'close',
            description: 'Close the current ticket',
            type: 1,
            options: [{ name: 'reason', description: 'Reason for closing', type: 3, required: false }]
        },
        { name: 'claim', description: 'Claim the current ticket', type: 1 },
        { name: 'unclaim', description: 'Release your claim on the current ticket', type: 1 },
        {
            name: 'add',
            description: 'Add a user to the current ticket',
            type: 1,
            options: [{ name: 'user', description: 'User to add', type: 6, required: true }]
        },
        {
            name: 'remove',
            description: 'Remove a user from the current ticket',
            type: 1,
            options: [{ name: 'user', description: 'User to remove', type: 6, required: true }]
        },
        { name: 'list', description: 'List all currently open tickets', type: 1 }
    ],

    async slashExecute(interaction, client) {
        const interactionWrapper = {
            guild: interaction.guild,
            channel: interaction.channel,
            author: interaction.user,
            member: interaction.member,
            mentions: { users: new Map(), members: new Map() },
            reply: async (options) => {
                if (interaction.deferred) return await interaction.editReply(options);
                if (interaction.replied) return await interaction.followUp(options);
                return await interaction.reply(options);
            }
        };

        const sub = interaction.options.getSubcommand();
        const args = [sub];

        if (sub === 'panel') {
            const channel = interaction.options.getChannel('channel');
            if (channel) args.push(`<#${channel.id}>`);
        } else if (sub === 'category') {
            args.push(interaction.options.getString('action'));
            const name = interaction.options.getString('name');
            const emojiOpt = interaction.options.getString('emoji');
            const desc = interaction.options.getString('description');
            if (name) args.push(name);
            if (emojiOpt) args.push(`::emoji::${emojiOpt}`);
            if (desc) args.push(`::desc::${desc}`);
        } else if (sub === 'close') {
            const reason = interaction.options.getString('reason');
            if (reason) args.push(...reason.split(' '));
        } else if (sub === 'add' || sub === 'remove') {
            const user = interaction.options.getUser('user');
            if (user) args.push(`<@${user.id}>`);
        }

        return module.exports.execute(interactionWrapper, args, client, client.prefix);
    },

    async execute(context, args, client, prefix) {
        const sub = (args[0] || '').toLowerCase();
        if (!sub) return module.exports.sendHelp(context, prefix);
        const rest = args.slice(1);

        switch (sub) {
            case 'setup': return module.exports.setup(context, client);
            case 'panel': return module.exports.panel(context, rest, client);
            case 'category':
            case 'categories': return module.exports.categoryCmd(context, rest, client);
            case 'close': return module.exports.closeTicket(context, rest, client);
            case 'claim': return module.exports.claimTicket(context, client);
            case 'unclaim': return module.exports.unclaimTicket(context, client);
            case 'add': return module.exports.addUser(context, rest, client);
            case 'remove': return module.exports.removeUser(context, rest, client);
            case 'list': return module.exports.listTickets(context, client);
            default: return module.exports.sendHelp(context, prefix);
        }
    },

    async sendHelp(context, prefix) {
        const content =
            '```[] = Optional Argument\n<> = Required Argument```' +
            `\n**Usage:** \`\`${prefix}ticket <setup/panel/category/close/claim/unclaim/add/remove/list>\`\`` +
            `\n${emoji.blank}${emoji.wickarrow} \`setup\` — configure the ticket category, log channel and support role\n` +
            `${emoji.blank}${emoji.wickarrow} \`panel [#channel]\` — send the ticket-opening dropdown panel\n` +
            `${emoji.blank}${emoji.wickarrow} \`category <add/remove/list> [name]\` — manage the dropdown categories\n` +
            `${emoji.blank}${emoji.wickarrow} \`claim / unclaim\` — claim or release a ticket (staff only)\n` +
            `${emoji.blank}${emoji.wickarrow} \`close [reason]\` — close the current ticket\n` +
            `${emoji.blank}${emoji.wickarrow} \`add / remove <@user>\` — add or remove a user from a ticket\n` +
            `${emoji.blank}${emoji.wickarrow} \`list\` — list all currently open tickets`;
        return context.reply(box(content));
    },

    async success(context, msg) {
        try {
            return await context.reply(box(`${emoji.check} ${msg}`, 0xFFD700));
        } catch (e) {
            return await context.channel?.send(box(`${emoji.check} ${msg}`, 0xFFD700)).catch(() => null);
        }
    },

    async error(context, msg) {
        try {
            return await context.reply(box(`${emoji.warn} ${msg}`, 0xFFD700));
        } catch (e) {
            return await context.channel?.send(box(`${emoji.warn} ${msg}`, 0xFFD700)).catch(() => null);
        }
    },

    async ephemeralNotice(interaction, msg, color = 0xFFD700) {
        const payload = { ...box(msg, color), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 };
        if (interaction.replied || interaction.deferred) return interaction.followUp(payload).catch(() => { });
        return interaction.reply(payload).catch(() => { });
    },

    // ---------- Setup wizard ----------
    async setup(context, client) {
        const guild = context.guild;
        const member = context.member;
        const user = context.author || context.user;
        const isOwner = client.owners.includes(user.id);
        if (!member.permissions.has(PermissionFlagsBits.ManageGuild) && !isOwner) {
            return this.error(context, 'You need `Manage Server` permission to set up the ticket system.');
        }

        const existing = getConfig(client, guild.id);
        let ticketCategoryId = existing.categoryId;
        let logChannelId = existing.logChannelId;
        let supportRoleId = existing.supportRoleId;

        const renderContent = () =>
            `### ${emoji.info} Ticket System Setup\n` +
            `${emoji.blank}${emoji.wickarrow} **Ticket Category:** ${ticketCategoryId ? `<#${ticketCategoryId}>` : '\`Not set\`'}\n` +
            `${emoji.blank}${emoji.wickarrow} **Log Channel:** ${logChannelId ? `<#${logChannelId}>` : '\`Not set\`'}\n` +
            `${emoji.blank}${emoji.wickarrow} **Support Role:** ${supportRoleId ? `<@&${supportRoleId}>` : '\`Not set\`'}\n\n` +
            `-# Use the menus below, then press **Save**. New ticket channels are created inside the selected category.`;

        const buildComponents = () => {
            const categorySelect = new ActionRowBuilder().addComponents(
                new ChannelSelectMenuBuilder().setCustomId('ticket_setup_category').setPlaceholder('Select the category for new ticket channels').addChannelTypes(ChannelType.GuildCategory)
            );
            const logSelect = new ActionRowBuilder().addComponents(
                new ChannelSelectMenuBuilder().setCustomId('ticket_setup_logs').setPlaceholder('Select the ticket log channel').addChannelTypes(ChannelType.GuildText)
            );
            const roleSelect = new ActionRowBuilder().addComponents(
                new RoleSelectMenuBuilder().setCustomId('ticket_setup_role').setPlaceholder('Select the support role')
            );
            const controlRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('ticket_setup_save').setLabel('Save').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('ticket_setup_close').setLabel('Cancel').setStyle(ButtonStyle.Danger)
            );
            return [categorySelect, logSelect, roleSelect, controlRow];
        };

        const msg = await context.reply({
            components: [new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(new TextDisplayBuilder().setContent(renderContent())), ...buildComponents()],
            flags: MessageFlags.IsComponentsV2
        });

        const collector = msg.createMessageComponentCollector({ filter: (i) => i.user.id === user.id, time: 300000 });

        collector.on('collect', async (i) => {
            if (i.customId === 'ticket_setup_category') {
                ticketCategoryId = i.values[0];
            } else if (i.customId === 'ticket_setup_logs') {
                logChannelId = i.values[0];
            } else if (i.customId === 'ticket_setup_role') {
                supportRoleId = i.values[0];
            } else if (i.customId === 'ticket_setup_close') {
                collector.stop();
                return i.message.delete().catch(() => { });
            } else if (i.customId === 'ticket_setup_save') {
                client.db.ticketconfig.set(guild.id, {
                    categoryId: ticketCategoryId || null,
                    logChannelId: logChannelId || null,
                    supportRoleId: supportRoleId || null,
                    categories: existing.categories,
                    ticketCounter: existing.ticketCounter || 0
                });
                collector.stop();
                return i.update({
                    components: [new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(new TextDisplayBuilder().setContent(`${emoji.check} Ticket system configured!\n\n${renderContent()}`))],
                    flags: MessageFlags.IsComponentsV2
                }).catch(() => { });
            }

            return i.update({
                components: [new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(new TextDisplayBuilder().setContent(renderContent())), ...buildComponents()],
                flags: MessageFlags.IsComponentsV2
            }).catch(() => { });
        });

        collector.on('end', (collected, reason) => {
            if (reason === 'time') {
                msg.edit({
                    components: [new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(new TextDisplayBuilder().setContent(`${renderContent()}\n\n-# This setup menu has expired.`))]
                }).catch(() => { });
            }
        });
    },

    // ---------- Category management ----------
    async categoryCmd(context, rest, client) {
        const member = context.member;
        const user = context.author || context.user;
        const isOwner = client.owners.includes(user.id);
        if (!member.permissions.has(PermissionFlagsBits.ManageGuild) && !isOwner) {
            return this.error(context, 'You need `Manage Server` permission to manage ticket categories.');
        }

        const guildId = context.guild.id;
        const config = getConfig(client, guildId);
        const categories = [...config.categories];
        const action = (rest[0] || '').toLowerCase();

        if (action === 'list') {
            if (!categories.length) return this.error(context, 'No categories are configured.');
            const content = `**Ticket Categories**\n` +
                categories.map(c => `${emoji.blank}${emoji.wickarrow} ${c.emoji || '🎫'} **${c.label}** \`(${c.id})\` — ${c.description || 'No description'}`).join('\n');
            return context.reply(box(content));
        }

        if (action === 'add') {
            let words = rest.slice(1);
            let emojiVal = null;
            let descVal = null;
            words = words.filter((w) => {
                if (w.startsWith('::emoji::')) { emojiVal = w.replace('::emoji::', ''); return false; }
                if (w.startsWith('::desc::')) { descVal = w.replace('::desc::', ''); return false; }
                return true;
            });
            const label = words.join(' ').trim();
            if (!label) return this.error(context, 'Usage: `ticket category add <name>`');
            if (categories.length >= 20) return this.error(context, 'You can have a maximum of 20 ticket categories.');

            const id = label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 80) || `cat${Date.now()}`;
            if (categories.some((c) => c.id === id)) return this.error(context, 'A category with a similar name already exists.');

            categories.push({ id, label: label.slice(0, 100), emoji: emojiVal || '🎫', description: (descVal || '').slice(0, 100) });
            client.db.ticketconfig.set(guildId, { categoryId: config.categoryId, logChannelId: config.logChannelId, supportRoleId: config.supportRoleId, categories, ticketCounter: config.ticketCounter || 0 });
            return this.success(context, `Added ticket category **${label}**.`);
        }

        if (action === 'remove') {
            const query = rest.slice(1).join(' ').trim().toLowerCase();
            if (!query) return this.error(context, 'Usage: `ticket category remove <name or id>`');
            const idx = categories.findIndex((c) => c.id === query || c.label.toLowerCase() === query);
            if (idx === -1) return this.error(context, 'Category not found. Use `ticket category list` to see all categories.');
            if (categories.length <= 1) return this.error(context, 'You must keep at least one ticket category.');

            const removed = categories.splice(idx, 1)[0];
            client.db.ticketconfig.set(guildId, { categoryId: config.categoryId, logChannelId: config.logChannelId, supportRoleId: config.supportRoleId, categories, ticketCounter: config.ticketCounter || 0 });
            return this.success(context, `Removed ticket category **${removed.label}**.`);
        }

        return this.error(context, 'Usage: `ticket category <add/remove/list> [name]`');
    },

    // ---------- Panel ----------
    async panel(context, rest, client) {
        const guild = context.guild;
        const member = context.member;
        const user = context.author || context.user;
        const isOwner = client.owners.includes(user.id);
        if (!member.permissions.has(PermissionFlagsBits.ManageGuild) && !isOwner) {
            return this.error(context, 'You need `Manage Server` permission to send the ticket panel.');
        }

        const config = getConfig(client, guild.id);
        if (!config.categoryId) {
            return this.error(context, 'Please run `ticket setup` first to configure the ticket category.');
        }

        let targetChannel = context.channel;
        const chanArg = rest[0];
        if (chanArg) {
            const chanId = chanArg.replace(/[<#>]/g, '');
            const resolved = guild.channels.cache.get(chanId);
            if (!resolved) return this.error(context, 'Could not find that channel.');
            targetChannel = resolved;
        }

        const options = config.categories.slice(0, 25).map((c) => ({
            label: c.label.slice(0, 100),
            value: c.id,
            description: (c.description || '').slice(0, 100) || undefined,
            emoji: c.emoji || undefined
        }));

        const select = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('ticket_open_select')
                .setPlaceholder('Select a category to open a ticket')
                .addOptions(options)
        );

        const content = `### ${emoji.info} Need Help?\nSelect a category below to open a support ticket. Our team will assist you shortly.`;

        await targetChannel.send({
            components: [new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(new TextDisplayBuilder().setContent(content)), select],
            flags: MessageFlags.IsComponentsV2
        });

        return this.success(context, `Ticket panel sent in ${targetChannel}.`);
    },

    // ---------- Ticket lifecycle (prefix/slash commands, used inside a ticket channel) ----------
    async claimTicket(context, client) {
        const channel = context.channel;
        const ticket = client.db.tickets.get(channel.id);
        if (!ticket) return this.error(context, 'This is not an active ticket channel.');
        if (ticket.status === 'closed') return this.error(context, 'This ticket is closed.');
        if (ticket.claimedBy) return this.error(context, `This ticket is already claimed by <@${ticket.claimedBy}>.`);

        const member = context.member;
        const user = context.author || context.user;
        const config = getConfig(client, context.guild.id);
        if (!isStaffMember(client, config, member)) return this.error(context, 'Only support staff can claim tickets.');

        client.db.tickets.set(channel.id, { claimedBy: user.id });
        const updated = { ...ticket, claimedBy: user.id };
        await updateTicketMessage(channel, updated);
        return this.success(context, 'You have claimed this ticket.');
    },

    async unclaimTicket(context, client) {
        const channel = context.channel;
        const ticket = client.db.tickets.get(channel.id);
        if (!ticket) return this.error(context, 'This is not an active ticket channel.');
        if (!ticket.claimedBy) return this.error(context, 'This ticket is not claimed.');

        const member = context.member;
        const user = context.author || context.user;
        const config = getConfig(client, context.guild.id);
        const isOwnerOfClaim = ticket.claimedBy === user.id;
        if (!isOwnerOfClaim && !isStaffMember(client, config, member)) {
            return this.error(context, 'Only the claimer or support staff can unclaim this ticket.');
        }

        client.db.tickets.set(channel.id, { claimedBy: null });
        const updated = { ...ticket, claimedBy: null };
        await updateTicketMessage(channel, updated);
        return this.success(context, 'This ticket has been unclaimed.');
    },

    async closeTicket(context, rest, client) {
        const channel = context.channel;
        const ticket = client.db.tickets.get(channel.id);
        if (!ticket) return this.error(context, 'This is not an active ticket channel.');
        if (ticket.status === 'closed') return this.error(context, 'This ticket is already closed.');

        const user = context.author || context.user;
        const reason = rest.join(' ').trim() || null;
        const closedAt = Date.now();

        client.db.tickets.set(channel.id, { status: 'closed', closedAt, closedBy: user.id });
        const updated = { ...ticket, status: 'closed', closedAt, closedBy: user.id };

        await updateTicketMessage(channel, updated);
        await channel.permissionOverwrites.edit(ticket.userId, { SendMessages: false }).catch(() => { });

        const config = getConfig(client, context.guild.id);
        if (config.logChannelId) {
            const logChannel = context.guild.channels.cache.get(config.logChannelId);
            if (logChannel) logChannel.send(box(`${emoji.cross} Ticket ${channel} closed by <@${user.id}>.${reason ? ` Reason: ${reason}` : ''}`, 0xFFD700)).catch(() => { });
        }

        return this.success(context, `Ticket closed.${reason ? ` Reason: ${reason}` : ''}`);
    },

    async addUser(context, rest, client) {
        const channel = context.channel;
        const ticket = client.db.tickets.get(channel.id);
        if (!ticket) return this.error(context, 'This command must be used inside a ticket channel.');

        const userId = await resolveUserId(client, rest[0]);
        if (!userId) return this.error(context, 'Usage: `ticket add <@user>`');

        await channel.permissionOverwrites.edit(userId, {
            ViewChannel: true, SendMessages: true, ReadMessageHistory: true
        }).catch(() => { });

        return this.success(context, `Added <@${userId}> to this ticket.`);
    },

    async removeUser(context, rest, client) {
        const channel = context.channel;
        const ticket = client.db.tickets.get(channel.id);
        if (!ticket) return this.error(context, 'This command must be used inside a ticket channel.');

        const userId = await resolveUserId(client, rest[0]);
        if (!userId) return this.error(context, 'Usage: `ticket remove <@user>`');
        if (userId === ticket.userId) return this.error(context, 'You cannot remove the ticket opener.');

        await channel.permissionOverwrites.delete(userId).catch(() => { });
        return this.success(context, `Removed <@${userId}> from this ticket.`);
    },

    async listTickets(context, client) {
        const member = context.member;
        const user = context.author || context.user;
        const isOwner = client.owners.includes(user.id);
        if (!member.permissions.has(PermissionFlagsBits.ManageGuild) && !isOwner) {
            return this.error(context, 'You need `Manage Server` permission to list tickets.');
        }

        const all = client.db.tickets.getAllForGuild(context.guild.id).filter((t) => t.status !== 'closed');
        if (!all.length) return this.success(context, 'There are no open tickets.');

        const content = `**Open Tickets (${all.length})**\n` +
            all.slice(0, 25).map((t) => `${emoji.blank}${emoji.wickarrow} <#${t.channelId}> — <@${t.userId}>${t.claimedBy ? ` (claimed by <@${t.claimedBy}>)` : ''}`).join('\n');
        return context.reply(box(content));
    },

    // ---------- Persistent components (dropdown panel + ticket-channel buttons) ----------
    async componentsV2(interaction, client) {
        if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_open_select') {
            return this.handleOpenSelect(interaction, client);
        }

        if (interaction.isButton()) {
            const id = interaction.customId;
            if (id === 'ticket_claim') return this.handleClaim(interaction, client);
            if (id === 'ticket_unclaim') return this.handleUnclaim(interaction, client);
            if (id === 'ticket_close') return this.handleCloseButton(interaction, client);
            if (id === 'ticket_closeconfirm') return this.handleCloseConfirm(interaction, client);
            if (id === 'ticket_closecancel') return this.handleCloseCancel(interaction, client);
            if (id === 'ticket_reopen') return this.handleReopen(interaction, client);
            if (id === 'ticket_delete') return this.handleDelete(interaction, client);
        }
        // Anything else (e.g. the setup-wizard selects) is owned by its own collector; ignore here.
    },

    async handleOpenSelect(interaction, client) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => { });
        const guild = interaction.guild;
        const config = getConfig(client, guild.id);

        if (!config.categoryId) {
            return interaction.editReply(box('The ticket system has not been fully configured yet. Please contact an admin.', 0xFFD700)).catch(() => { });
        }

        const categoryDef = config.categories.find((c) => c.id === interaction.values[0]) || { id: interaction.values[0], label: 'Support' };

        const existingTicket = client.db.tickets.getOpenForUser(guild.id, interaction.user.id);
        if (existingTicket) {
            return interaction.editReply(box(`You already have an open ticket: <#${existingTicket.channelId}>`, 0xFFD700)).catch(() => { });
        }

        const parent = guild.channels.cache.get(config.categoryId);
        if (!parent) {
            return interaction.editReply(box('The configured ticket category no longer exists. Please ask an admin to run `ticket setup` again.', 0xFFD700)).catch(() => { });
        }

        const counter = (config.ticketCounter || 0) + 1;
        client.db.ticketconfig.set(guild.id, { categoryId: config.categoryId, logChannelId: config.logChannelId, supportRoleId: config.supportRoleId, categories: config.categories, ticketCounter: counter });

        const overwrites = [
            { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
            { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] }
        ];
        if (config.supportRoleId) {
            overwrites.push({ id: config.supportRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
        }

        let channel;
        try {
            channel = await guild.channels.create({
                name: `ticket-${counter.toString().padStart(4, '0')}`,
                type: ChannelType.GuildText,
                parent: parent.id,
                topic: `Ticket | ${categoryDef.label} | Opened by ${interaction.user.tag} (${interaction.user.id})`,
                permissionOverwrites: overwrites
            });
        } catch (e) {
            console.error('Ticket creation error:', e);
            return interaction.editReply(box('I could not create a ticket channel. Please check my permissions.', 0xFFD700)).catch(() => { });
        }

        const ticket = {
            guildId: guild.id,
            userId: interaction.user.id,
            categoryId: categoryDef.id,
            categoryLabel: categoryDef.label,
            status: 'open',
            claimedBy: null,
            createdAt: Date.now(),
            closedAt: null,
            closedBy: null
        };

        const openingMsg = await channel.send({
            content: config.supportRoleId ? `<@&${config.supportRoleId}> ${interaction.user}` : `${interaction.user}`,
            components: [renderTicketContainer(ticket), renderTicketButtons(ticket)],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => null);

        client.db.tickets.set(channel.id, { ...ticket, messageId: openingMsg ? openingMsg.id : null });

        if (config.logChannelId) {
            const logChannel = guild.channels.cache.get(config.logChannelId);
            if (logChannel) logChannel.send(box(`${emoji.check} Ticket ${channel} opened by <@${interaction.user.id}> — Category: **${categoryDef.label}**`, 0xFFD700)).catch(() => { });
        }

        return interaction.editReply(box(`${emoji.check} Your ticket has been created: ${channel}`, 0xFFD700)).catch(() => { });
    },

    async handleClaim(interaction, client) {
        const ticket = client.db.tickets.get(interaction.channel.id);
        if (!ticket) return this.ephemeralNotice(interaction, 'This is not an active ticket channel.');
        if (ticket.status === 'closed') return this.ephemeralNotice(interaction, 'This ticket is closed.');
        if (ticket.claimedBy) return this.ephemeralNotice(interaction, `This ticket is already claimed by <@${ticket.claimedBy}>.`);

        const config = getConfig(client, interaction.guild.id);
        if (!isStaffMember(client, config, interaction.member)) return this.ephemeralNotice(interaction, 'Only support staff can claim tickets.');

        client.db.tickets.set(interaction.channel.id, { claimedBy: interaction.user.id });
        const updated = { ...ticket, claimedBy: interaction.user.id };

        await interaction.update({
            components: [renderTicketContainer(updated), renderTicketButtons(updated)],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => { });
    },

    async handleUnclaim(interaction, client) {
        const ticket = client.db.tickets.get(interaction.channel.id);
        if (!ticket) return this.ephemeralNotice(interaction, 'This is not an active ticket channel.');
        if (!ticket.claimedBy) return this.ephemeralNotice(interaction, 'This ticket is not claimed.');

        const config = getConfig(client, interaction.guild.id);
        const isOwnerOfClaim = ticket.claimedBy === interaction.user.id;
        if (!isOwnerOfClaim && !isStaffMember(client, config, interaction.member)) {
            return this.ephemeralNotice(interaction, 'Only the claimer or support staff can unclaim this ticket.');
        }

        client.db.tickets.set(interaction.channel.id, { claimedBy: null });
        const updated = { ...ticket, claimedBy: null };

        await interaction.update({
            components: [renderTicketContainer(updated), renderTicketButtons(updated)],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => { });
    },

    async handleCloseButton(interaction, client) {
        const ticket = client.db.tickets.get(interaction.channel.id);
        if (!ticket) return this.ephemeralNotice(interaction, 'This is not an active ticket channel.');
        if (ticket.status === 'closed') return this.ephemeralNotice(interaction, 'This ticket is already closed.');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ticket_closeconfirm').setLabel('Confirm Close').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('ticket_closecancel').setLabel('Cancel').setStyle(ButtonStyle.Secondary)
        );
        const display = new TextDisplayBuilder().setContent(`${emoji.warn} Are you sure you want to close this ticket?`);

        await interaction.reply({
            components: [new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(display), row],
            flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
        }).catch(() => { });
    },

    async handleCloseCancel(interaction) {
        await interaction.update(box('Cancelled.', 0xFFD700)).catch(() => { });
    },

    async handleCloseConfirm(interaction, client) {
        const ticket = client.db.tickets.get(interaction.channel.id);
        if (!ticket || ticket.status === 'closed') {
            return interaction.update(box('This ticket is already closed or no longer exists.', 0xFFD700)).catch(() => { });
        }

        const closedAt = Date.now();
        client.db.tickets.set(interaction.channel.id, { status: 'closed', closedAt, closedBy: interaction.user.id });
        const updated = { ...ticket, status: 'closed', closedAt, closedBy: interaction.user.id };

        await interaction.update(box(`${emoji.check} Ticket closed.`, 0xFFD700)).catch(() => { });
        await interaction.channel.permissionOverwrites.edit(ticket.userId, { SendMessages: false }).catch(() => { });
        await updateTicketMessage(interaction.channel, updated);

        const config = getConfig(client, interaction.guild.id);
        if (config.logChannelId) {
            const logChannel = interaction.guild.channels.cache.get(config.logChannelId);
            if (logChannel) logChannel.send(box(`${emoji.cross} Ticket ${interaction.channel} closed by <@${interaction.user.id}>.`, 0xFFD700)).catch(() => { });
        }
    },

    async handleReopen(interaction, client) {
        const ticket = client.db.tickets.get(interaction.channel.id);
        if (!ticket) return this.ephemeralNotice(interaction, 'This is not an active ticket channel.');

        const config = getConfig(client, interaction.guild.id);
        if (!isStaffMember(client, config, interaction.member)) return this.ephemeralNotice(interaction, 'Only support staff can reopen tickets.');

        client.db.tickets.set(interaction.channel.id, { status: 'open', closedAt: null, closedBy: null });
        const updated = { ...ticket, status: 'open', closedAt: null, closedBy: null };

        await interaction.channel.permissionOverwrites.edit(ticket.userId, { SendMessages: true }).catch(() => { });

        await interaction.update({
            components: [renderTicketContainer(updated), renderTicketButtons(updated)],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => { });
    },

    async handleDelete(interaction, client) {
        const ticket = client.db.tickets.get(interaction.channel.id);
        if (!ticket) return this.ephemeralNotice(interaction, 'This is not an active ticket channel.');

        const config = getConfig(client, interaction.guild.id);
        if (!isStaffMember(client, config, interaction.member)) return this.ephemeralNotice(interaction, 'Only support staff can delete tickets.');

        await interaction.reply(box(`${emoji.check} Deleting this ticket in 5 seconds...`, 0xFFD700)).catch(() => { });
        client.db.tickets.delete(interaction.channel.id);
        setTimeout(() => {
            interaction.channel.delete('Ticket deleted').catch(() => { });
        }, 5000);
    }
};
