const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  MessageFlags
} = require("discord.js");

module.exports = {
  name: "invite",
  category: "Information",
  description: "Get the bot's invite link",
  aliases: ["inv"],
  cooldown: 5,
  slashOptions: [],
  async slashExecute(interaction, client) {
    const interactionWrapper = {
      guild: interaction.guild,
      channel: interaction.channel,
      author: interaction.user,
      member: interaction.member,
      createdTimestamp: interaction.createdTimestamp,
      reply: async (options) => {
        if (interaction.deferred) {
          return await interaction.editReply(options);
        } else if (interaction.replied) {
          return await interaction.followUp(options);
        } else {
          return await interaction.reply(options);
        }
      },
    };

    const args = [];
    if (interaction.options) {
      const options = interaction.options.data;
      for (const option of options) {
        if (option.value !== undefined) {
          args.push(option.value.toString());
        }
      }
    }

    const prefix = client.prefix;
    return this.execute(interactionWrapper, args, client, prefix);
  },
  async execute(message, args, client, prefix) {
    const inviteRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("Invite")
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.com/oauth2/authorize?client_id=1520115067595522179&permissions=39722071411520&integration_type=0&scope=bot`),
    );

    const separator = new SeparatorBuilder();

    const inviteDisplay = new TextDisplayBuilder()
      .setContent(`**${client.emoji.info} Invite ${client.user.username} to your server.**`);

    const container = new ContainerBuilder().setAccentColor(0xFFD700)
      .addTextDisplayComponents(inviteDisplay)
      .addSeparatorComponents(separator)
      .addActionRowComponents(inviteRow);

    return message.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });
  }
};
