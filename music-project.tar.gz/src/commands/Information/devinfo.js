const {
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  SeparatorBuilder,
  MessageFlags,
} = require("discord.js");

// ---- Edit these to customize the team shown ----
const TEAM_NAME = "AxC Music";
const ACCENT_COLOR = 0xFFD700; // matches config.color (#8A5CFF)

// role: used to look up an emoji from src/emojis.js (owner, developer, manager, admin, staff, vip)
// id: Discord user ID, used to pull a live avatar + username. Leave "" to just show the name/title as text.
const DEV = [
  { name: "Prince", title: "The Main Developer", role: "developer", id: "" },
];

const CORE_TEAM = [
  { name: "Vivek", title: "Helps in designing", role: "manager", id: "" },
  { name: "Ayush", title: "Manages the Discord Server", role: "admin", id: "" },
  { name: "Divyanshuu", title: "High authority, manages overall bot", role: "manager", id: "" },
];

const OTHERS = [
  { name: "Soon", title: "", role: "vip", id: "" },
  { name: "Soon", title: "", role: "vip", id: "" },
];
// --------------------------------------------------

module.exports = {
  name: "devinfo",
  category: "Information",
  description: `Show a premium-styled overview of the ${TEAM_NAME} team`,
  args: false,
  usage: "",
  aliases: ["team", "devteam", "anikxcheats"],
  userPerms: [],
  owner: false,
  slashOptions: [],
  async slashExecute(interaction, client) {
    const interactionWrapper = {
      guild: interaction.guild,
      channel: interaction.channel,
      author: interaction.user,
      member: interaction.member,
      createdTimestamp: interaction.createdTimestamp,
      reply: async (options) => {
        if (interaction.deferred) {
          return await interaction.editReply(options);
        } else if (interaction.replied) {
          return await interaction.followUp(options);
        } else {
          return await interaction.reply(options);
        }
      },
    };

    const args = [];
    if (interaction.options) {
      const options = interaction.options.data;
      for (const option of options) {
        if (option.value !== undefined) {
          args.push(option.value.toString());
        }
      }
    }

    const prefix = client.prefix;
    return this.execute(interactionWrapper, args, client, prefix);
  },

  async execute(message, args, client, prefix) {
    const emoji = client.emoji || {};
    const roleIcon = (role) => emoji[role] || emoji.vip || "";

    const container = new ContainerBuilder().setAccentColor(ACCENT_COLOR);

    // Header
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${emoji.owner || "👑"} ${TEAM_NAME} — Premium Team`
      ),
      new TextDisplayBuilder().setContent(
        `-# The people behind ${TEAM_NAME}. Thumbnails link to each member's live avatar.`
      )
    );
    container.addSeparatorComponents(new SeparatorBuilder());

    // Builds one "premium" row per member: name/title as a Section,
    // with either their live Discord avatar or a role emoji as the accessory thumbnail.
    const addMemberSection = async (member) => {
      const label = member.title
        ? `**${member.name}**\n${roleIcon(member.role)} ${member.title}`
        : `**${member.name}**\n${roleIcon(member.role)} ${member.role.charAt(0).toUpperCase() + member.role.slice(1)}`;

      const section = new SectionBuilder().addTextDisplayComponents(
        new TextDisplayBuilder().setContent(label)
      );

      let avatarURL = null;
      if (member.id) {
        const user = await client.users.fetch(member.id).catch(() => null);
        if (user) avatarURL = user.displayAvatarURL({ extension: "png", size: 128 });
      }

      section.setThumbnailAccessory(
        new ThumbnailBuilder().setURL(
          avatarURL || client.user.displayAvatarURL({ extension: "png", size: 128 })
        )
      );

      container.addSectionComponents(section);
    };

    const addGroupHeader = (label) => {
      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`### ${label}`)
      );
    };

    addGroupHeader(`${emoji.developer || ""} Developer`);
    for (const dev of DEV) await addMemberSection(dev);

    container.addSeparatorComponents(new SeparatorBuilder());
    addGroupHeader(`${emoji.manager || ""} Core Team`);
    for (const member of CORE_TEAM) await addMemberSection(member);

    if (OTHERS.length) {
      container.addSeparatorComponents(new SeparatorBuilder());
      addGroupHeader(`${emoji.vip || ""} Others`);
      for (const member of OTHERS) await addMemberSection(member);
    }

    container.addSeparatorComponents(new SeparatorBuilder());
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `-# ${emoji.check || ""} ${TEAM_NAME} • Requested by ${message.author.tag || message.author.username}`
      )
    );

    return message.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
    });
  },
};
