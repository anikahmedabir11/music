const {
    MessageFlags,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder
} = require('discord.js');

module.exports = {
    name: 'afk',
    description: 'Set yourself as AFK. I\'ll notify anyone who mentions you while you\'re away.',
    category: 'Utility',
    usage: 'afk [reason]',
    example: 'afk Sleeping, back in a bit',
    aliases: [],
    cooldown: 3,
    slashOptions: [
        {
            name: 'reason',
            description: 'The reason you are going AFK',
            type: 3,
            required: false
        }
    ],

    async slashExecute(interaction, client) {
        const interactionWrapper = {
            guild: interaction.guild,
            channel: interaction.channel,
            author: interaction.user,
            member: interaction.member,
            createdTimestamp: interaction.createdTimestamp,
            reply: async (options) => {
                if (interaction.deferred) {
                    return await interaction.editReply(options);
                } else if (interaction.replied) {
                    return await interaction.followUp(options);
                } else {
                    return await interaction.reply(options);
                }
            },
        };

        const reason = interaction.options?.getString?.('reason');
        const args = reason ? reason.split(/ +/) : [];

        return this.execute(interactionWrapper, args, client);
    },

    async execute(message, args, client) {
        const reason = args.join(' ').slice(0, 200) || 'AFK';

        const since = client.db.afk.set(message.guild.id, message.author.id, reason);

        const display = new TextDisplayBuilder()
            .setContent(
                `### ${client.emoji.check} You're now AFK\n` +
                `> ${client.emoji.dot} **Reason:** ${reason}\n` +
                `> ${client.emoji.dot} **Since:** <t:${Math.floor(since / 1000)}:R>\n\n` +
                `-# I'll let anyone who pings you know you're away.`
            );

        const container = new ContainerBuilder().setAccentColor(0xFFD700)
            .addTextDisplayComponents(display);

        return message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
