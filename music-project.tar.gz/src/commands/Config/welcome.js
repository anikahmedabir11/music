const {
  PermissionsBitField,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  MessageFlags
} = require("discord.js");
const { buildWelcomeEmbed, buildWelcomeButtons } = require("../../utils/welcomeUtils");

const DEFAULT_MESSAGE = "Welcome {user.mention} to **{server}**! You are member #{membercount}.";
const DEFAULT_COLOR = "8A5CFF";

function reply(message, content, color = 0xFFD700) {
  const display = new TextDisplayBuilder().setContent(content);
  const container = new ContainerBuilder().setAccentColor(color)
    .addTextDisplayComponents(display);

  return message.channel.send({
    components: [container],
    flags: MessageFlags.IsComponentsV2
  });
}

module.exports = {
  name: "welcome",
  aliases: ["welcomer", "greet"],
  category: "Config",
  description: "Configure the welcome message shown when a member joins",
  usage: "<channel/message/toggle/color/thumbnail/thumbnailimage/image/footer/author/button/test/reset/variables> [value]",
  userPerms: ["ManageGuild"],
  args: false,
  cooldown: 3,
  subCommands: ["status", "channel", "message", "toggle", "color", "thumbnail", "thumbnailimage", "image", "footer", "author", "button", "test", "reset", "variables"],
  slashOptions: [
    {
      name: "action",
      description: "What you want to configure or view",
      type: 3,
      required: true,
      choices: [
        { name: "status", value: "status" },
        { name: "channel", value: "channel" },
        { name: "message", value: "message" },
        { name: "toggle", value: "toggle" },
        { name: "color", value: "color" },
        { name: "thumbnail", value: "thumbnail" },
        { name: "thumbnailimage", value: "thumbnailimage" },
        { name: "image", value: "image" },
        { name: "footer", value: "footer" },
        { name: "author", value: "author" },
        { name: "button", value: "button" },
        { name: "test", value: "test" },
        { name: "reset", value: "reset" },
        { name: "variables", value: "variables" }
      ]
    },
    {
      name: "channel",
      description: "Channel to send welcome messages in (used with action: channel)",
      type: 7,
      required: false
    },
    {
      name: "value",
      description: "Text value for message/color/image/footer/thumbnail(on/off)",
      type: 3,
      required: false
    }
  ],

  async slashExecute(interaction, client) {
    const interactionWrapper = {
      guild: interaction.guild,
      channel: interaction.channel,
      author: interaction.user,
      member: interaction.member,
      mentions: { channels: { first: () => interaction.options.getChannel("channel") || null } },
      reply: async (options) => {
        try {
          if (interaction.deferred || interaction.replied) {
            return await interaction.editReply(options);
          }
          return await interaction.reply(options);
        } catch (e) {
          if (interaction.replied || interaction.deferred) {
            return await interaction.followUp(options).catch(() => { });
          }
        }
      },
    };

    const action = interaction.options.getString("action");
    const mentionedChannel = interaction.options.getChannel("channel");
    const value = interaction.options.getString("value");

    const args = [action];
    if (action === "channel" && mentionedChannel) {
      args.push(`<#${mentionedChannel.id}>`);
    } else if (value) {
      args.push(...value.split(" "));
    }

    return this.execute(interactionWrapper, args, client, client.prefix);
  },

  async execute(message, args, client, prefix) {
    if (!message.member.permissions.has(PermissionsBitField.resolve("ManageGuild"))) {
      return reply(
        message,
        `-# **${client.emoji.warn} You must have \`Manage Server\` permissions to use this command.**`,
        0xFFD700
      );
    }

    const action = args[0]?.toLowerCase();

    if (!action) {
      const content =
        `\`\`\`[] = Optional Argument\n<> = Required Argument\nDo NOT type these when using commands!\`\`\`` +
        `\n**Aliases:** \`\`welcomer, greet\`\`` +
        `\n**Usage:** \`\`channel/message/toggle/color/thumbnail/thumbnailimage/image/footer/author/test/reset/variables\`\`` +
        `\n-# Requested By ${message.author.displayName}`;
      return reply(message, content, 0xFFD700);
    }

    const guildId = message.guild.id;
    const current = client.db.welcome.get(guildId);

    switch (action) {
      case "status": {
        const settings = current || {
          enabled: false,
          channelId: null,
          message: DEFAULT_MESSAGE,
          color: DEFAULT_COLOR,
          thumbnail: true,
          thumbnailUrl: null,
          image: null,
          footer: null,
          authorEnabled: false,
          authorText: "{user}"
        };

        const content =
          `### ${client.emoji.info} Welcome Settings\n` +
          `**Status:** \`${settings.enabled ? "Enabled" : "Disabled"}\`\n` +
          `**Channel:** ${settings.channelId ? `<#${settings.channelId}>` : "\`Not set\`"}\n` +
          `**Color:** \`#${settings.color || DEFAULT_COLOR}\`\n` +
          `**Author Line:** \`${settings.authorEnabled ? "On" : "Off"}\`${settings.authorEnabled ? ` — \`${settings.authorText || "{user}"}\`` : ""}\n` +
          `**Avatar Thumbnail:** \`${settings.thumbnail ? "On" : "Off"}\`\n` +
          `**Custom Thumbnail Image:** ${settings.thumbnailUrl ? `[link](${settings.thumbnailUrl})` : "\`Not set (uses avatar)\`"}\n` +
          `**Banner Image:** ${settings.image ? `[link](${settings.image})` : "\`Not set\`"}\n` +
          `**Footer:** ${settings.footer ? `\`${settings.footer}\`` : "\`Default\`"}\n` +
          `**Buttons:** ${settings.buttons?.length ? settings.buttons.map(b => `[${b.label}](${b.url})`).join(" • ") : "\`None\`"}\n` +
          `**Message:**\n\`\`\`${settings.message || DEFAULT_MESSAGE}\`\`\`\n` +
          `-# Use \`${prefix}welcome variables\` to see available placeholders.`;

        return reply(message, content, 0xFFD700);
      }

      case "channel": {
        const channel =
          message.mentions.channels.first() ||
          message.guild.channels.cache.get(args[1]);

        if (!channel) {
          return reply(message, `**${client.emoji.warn} Please mention or provide a valid text channel.**`, 0xFFD700);
        }

        const perms = channel.permissionsFor(message.guild.members.me);
        if (!perms?.has(["ViewChannel", "SendMessages", "EmbedLinks"])) {
          return reply(message, `**${client.emoji.warn} I need \`View Channel\`, \`Send Messages\` and \`Embed Links\` permissions in ${channel}.**`, 0xFFD700);
        }

        client.db.welcome.set(guildId, {
          channelId: channel.id,
          enabled: current?.enabled ?? true,
          message: current?.message || DEFAULT_MESSAGE,
          color: current?.color || DEFAULT_COLOR,
          thumbnail: current?.thumbnail ?? true
        });

        return reply(message, `**${client.emoji.check} Welcome channel set to ${channel}.**`, 0xFFD700);
      }

      case "message": {
        const text = args.slice(1).join(" ");
        if (!text) {
          return reply(message, `**${client.emoji.warn} Please provide a welcome message. Use \`${prefix}welcome variables\` to see placeholders.**`, 0xFFD700);
        }

        client.db.welcome.set(guildId, {
          message: text,
          enabled: current?.enabled ?? false,
          channelId: current?.channelId || null,
          color: current?.color || DEFAULT_COLOR,
          thumbnail: current?.thumbnail ?? true
        });

        return reply(message, `**${client.emoji.check} Welcome message updated.**\n\`\`\`${text}\`\`\``, 0xFFD700);
      }

      case "toggle": {
        if (!current || !current.channelId) {
          return reply(message, `**${client.emoji.warn} Set a welcome channel first with \`${prefix}welcome channel #channel\`.**`, 0xFFD700);
        }

        const newState = !current.enabled;
        client.db.welcome.set(guildId, { enabled: newState });

        return reply(message, `**${client.emoji.check} Welcome messages are now \`${newState ? "Enabled" : "Disabled"}\`.**`, 0xFFD700);
      }

      case "color": {
        const hex = (args[1] || "").replace("#", "");
        if (!/^[0-9A-Fa-f]{6}$/.test(hex)) {
          return reply(message, `**${client.emoji.warn} Please provide a valid hex color, e.g. \`8A5CFF\`.**`, 0xFFD700);
        }

        client.db.welcome.set(guildId, {
          color: hex,
          enabled: current?.enabled ?? false,
          message: current?.message || DEFAULT_MESSAGE,
          channelId: current?.channelId || null,
          thumbnail: current?.thumbnail ?? true
        });

        return reply(message, `**${client.emoji.check} Embed color set to \`#${hex}\`.**`, parseInt(hex, 16));
      }

      case "thumbnail": {
        const opt = (args[1] || "").toLowerCase();
        if (!["on", "off"].includes(opt)) {
          return reply(message, `**${client.emoji.warn} Please specify \`on\` or \`off\`.**`, 0xFFD700);
        }

        client.db.welcome.set(guildId, {
          thumbnail: opt === "on",
          enabled: current?.enabled ?? false,
          message: current?.message || DEFAULT_MESSAGE,
          channelId: current?.channelId || null,
          color: current?.color || DEFAULT_COLOR
        });

        return reply(message, `**${client.emoji.check} Avatar thumbnail turned \`${opt === "on" ? "On" : "Off"}\`.**`, 0xFFD700);
      }

      case "image": {
        const url = args[1];
        if (!url) {
          return reply(message, `**${client.emoji.warn} Please provide an image URL, or type \`none\` to remove it.**`, 0xFFD700);
        }

        if (url.toLowerCase() === "none") {
          client.db.welcome.set(guildId, { image: null });
          return reply(message, `**${client.emoji.check} Banner image removed.**`, 0xFFD700);
        }

        if (!/^https?:\/\/.+\.(png|jpe?g|gif|webp)(\?.*)?$/i.test(url)) {
          return reply(message, `**${client.emoji.warn} Please provide a direct image link (png, jpg, gif or webp).**`, 0xFFD700);
        }

        client.db.welcome.set(guildId, {
          image: url,
          enabled: current?.enabled ?? false,
          message: current?.message || DEFAULT_MESSAGE,
          channelId: current?.channelId || null,
          color: current?.color || DEFAULT_COLOR,
          thumbnail: current?.thumbnail ?? true
        });

        return reply(message, `**${client.emoji.check} Banner image updated.**`, 0xFFD700);
      }

      case "footer": {
        const text = args.slice(1).join(" ");
        if (!text) {
          return reply(message, `**${client.emoji.warn} Please provide footer text, or type \`none\` to reset to default.**`, 0xFFD700);
        }

        client.db.welcome.set(guildId, { footer: text.toLowerCase() === "none" ? null : text });
        return reply(message, `**${client.emoji.check} Footer updated.**`, 0xFFD700);
      }

      case "author": {
        const opt = (args[1] || "").toLowerCase();

        if (opt === "on" || opt === "off") {
          client.db.welcome.set(guildId, {
            authorEnabled: opt === "on",
            authorText: current?.authorText || "{user}",
            enabled: current?.enabled ?? false,
            message: current?.message || DEFAULT_MESSAGE,
            channelId: current?.channelId || null,
            color: current?.color || DEFAULT_COLOR,
            thumbnail: current?.thumbnail ?? true
          });
          return reply(message, `**${client.emoji.check} Author line turned \`${opt === "on" ? "On" : "Off"}\`.**`, 0xFFD700);
        }

        const text = args.slice(1).join(" ");
        if (!text) {
          return reply(message, `**${client.emoji.warn} Usage:** \`${prefix}welcome author <on|off>\` or \`${prefix}welcome author <text>\` (e.g. \`{user}\` or \`{user.tag}\`).`, 0xFFD700);
        }

        client.db.welcome.set(guildId, {
          authorEnabled: true,
          authorText: text,
          enabled: current?.enabled ?? false,
          message: current?.message || DEFAULT_MESSAGE,
          channelId: current?.channelId || null,
          color: current?.color || DEFAULT_COLOR,
          thumbnail: current?.thumbnail ?? true
        });

        return reply(message, `**${client.emoji.check} Author line updated and enabled.**\n\`\`\`${text}\`\`\``, 0xFFD700);
      }

      case "thumbnailimage": {
        const url = args[1];
        if (!url) {
          return reply(message, `**${client.emoji.warn} Please provide an image URL, or type \`none\` to fall back to the member's avatar.**`, 0xFFD700);
        }

        if (url.toLowerCase() === "none") {
          client.db.welcome.set(guildId, { thumbnailUrl: null });
          return reply(message, `**${client.emoji.check} Custom thumbnail image removed — the member's avatar will be used instead (if avatar thumbnail is on).**`, 0xFFD700);
        }

        if (!/^https?:\/\/.+\.(png|jpe?g|gif|webp)(\?.*)?$/i.test(url)) {
          return reply(message, `**${client.emoji.warn} Please provide a direct image link (png, jpg, gif or webp).**`, 0xFFD700);
        }

        client.db.welcome.set(guildId, {
          thumbnailUrl: url,
          enabled: current?.enabled ?? false,
          message: current?.message || DEFAULT_MESSAGE,
          channelId: current?.channelId || null,
          color: current?.color || DEFAULT_COLOR
        });

        return reply(message, `**${client.emoji.check} Custom thumbnail image set.** This overrides the avatar thumbnail.`, 0xFFD700);
      }

      case "button": {
        const sub = (args[1] || "").toLowerCase();
        const existingButtons = current?.buttons || [];

        if (sub === "list") {
          if (existingButtons.length === 0) {
            return reply(message, `**${client.emoji.info} No buttons are configured.** Add one with \`${prefix}welcome button add <label> | <url> [| emoji]\`.`, 0xFFD700);
          }
          const list = existingButtons.map((b, i) => `\`${i + 1}.\` **${b.label}** — ${b.url}${b.emoji ? ` (${b.emoji})` : ""}`).join("\n");
          return reply(message, `### ${client.emoji.info} Welcome Buttons\n${list}`, 0xFFD700);
        }

        if (sub === "remove") {
          const index = parseInt(args[2], 10);
          if (!index || index < 1 || index > existingButtons.length) {
            return reply(message, `**${client.emoji.warn} Please provide a valid button number.** Use \`${prefix}welcome button list\` to see them.`, 0xFFD700);
          }
          const removed = existingButtons.splice(index - 1, 1)[0];
          client.db.welcome.set(guildId, { buttons: existingButtons });
          return reply(message, `**${client.emoji.check} Removed button \`${removed.label}\`.**`, 0xFFD700);
        }

        if (sub === "clear") {
          client.db.welcome.set(guildId, { buttons: [] });
          return reply(message, `**${client.emoji.check} All welcome buttons cleared.**`, 0xFFD700);
        }

        if (sub === "add") {
          if (existingButtons.length >= 5) {
            return reply(message, `**${client.emoji.warn} You can only have up to 5 buttons.** Remove one first with \`${prefix}welcome button remove <number>\`.`, 0xFFD700);
          }

          const raw = args.slice(2).join(" ");
          const parts = raw.split("|").map(p => p.trim()).filter(Boolean);
          const [label, url, emoji] = parts;

          if (!label || !url) {
            return reply(message, `**${client.emoji.warn} Usage:** \`${prefix}welcome button add <label> | <url> [| emoji]\`\n-# Example: \`${prefix}welcome button add Rules | https://discord.com/channels/.../rules | 📜\``, 0xFFD700);
          }

          if (!/^https?:\/\//i.test(url)) {
            return reply(message, `**${client.emoji.warn} The button URL must start with \`http://\` or \`https://\`.**`, 0xFFD700);
          }

          const newButton = { label: label.slice(0, 80), url };
          if (emoji) newButton.emoji = emoji;

          existingButtons.push(newButton);
          client.db.welcome.set(guildId, { buttons: existingButtons });

          return reply(message, `**${client.emoji.check} Added button \`${label}\`.** (${existingButtons.length}/5)`, 0xFFD700);
        }

        return reply(message, `**${client.emoji.warn} Usage:** \`${prefix}welcome button <add/remove/list/clear> [value]\`\n-# Add example: \`${prefix}welcome button add Rules | https://discord.com/channels/.../rules | 📜\``, 0xFFD700);
      }

      case "reset": {
        if (!current) {
          return reply(message, `**${client.emoji.info} There is no welcome configuration to reset.**`, 0xFFD700);
        }
        client.db.welcome.delete(guildId);
        return reply(message, `**${client.emoji.check} Welcome configuration has been reset.**`, 0xFFD700);
      }

      case "variables": {
        const content =
          `### ${client.emoji.info} Available Placeholders\n` +
          `\`{user}\` — username\n` +
          `\`{user.mention}\` — pings the member\n` +
          `\`{user.tag}\` — full tag (username#0000 or username)\n` +
          `\`{user.id}\` — user ID\n` +
          `\`{server}\` / \`{server.name}\` — server name\n` +
          `\`{server.id}\` — server ID\n` +
          `\`{membercount}\` — current member count\n` +
          `\`{membercount.ordinal}\` — member count as 1st, 2nd, 3rd...\n\n` +
          `-# Example: \`${prefix}welcome message Hey {user.mention}, welcome to {server}! You're member #{membercount}.\`\n` +
          `-# These placeholders also work in \`${prefix}welcome author <text>\` and \`${prefix}welcome footer <text>\`.`;

        return reply(message, content, 0xFFD700);
      }

      case "test": {
        const settings = current || {
          enabled: true,
          channelId: message.channel.id,
          message: DEFAULT_MESSAGE,
          color: DEFAULT_COLOR,
          thumbnail: true,
          image: null,
          footer: null,
          buttons: []
        };

        const embed = buildWelcomeEmbed(settings, message.member);
        const buttonRow = buildWelcomeButtons(settings);
        const payload = { content: `-# Preview of the welcome message:`, embeds: [embed] };
        if (buttonRow) payload.components = [buttonRow];

        return message.channel.send(payload);
      }

      default: {
        return reply(message, `**${client.emoji.warn} Unknown action.** Use \`${prefix}welcome\` for usage info.`, 0xFFD700);
      }
    }
  },
};
