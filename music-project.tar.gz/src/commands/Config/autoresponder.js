const {
    PermissionsBitField,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    MessageFlags
} = require("discord.js");
const emoji = require("../../emojis");

const MATCH_LABELS = {
    exact: "Exact match (message must equal the trigger)",
    startswith: "Starts with (message must start with the trigger)",
    contains: "Contains (trigger appears as a whole word/phrase)"
};

function box(color, content) {
    const display = new TextDisplayBuilder().setContent(content);
    return { components: [new ContainerBuilder().setAccentColor(color).addTextDisplayComponents(display)], flags: MessageFlags.IsComponentsV2 };
}

function splitTriggerResponse(raw) {
    const parts = raw.split("|");
    if (parts.length < 2) return null;
    const trigger = parts[0].trim();
    const response = parts.slice(1).join("|").trim();
    if (!trigger || !response) return null;
    return { trigger, response };
}

module.exports = {
    name: "autoresponder",
    aliases: ["ar", "autoresponse"],
    category: "Config",
    description: "Create custom trigger → response auto-replies for this server.",
    usage: "<add|addstart|addcontains|edit|remove|list|info|toggle|clear> [args]",
    example: "autoresponder add hello there | Hey {user}, welcome!",
    userPerms: ["ManageGuild"],
    args: false,
    cooldown: 3,
    subCommands: ["add", "addstart", "addcontains", "edit", "remove", "delete", "list", "info", "toggle", "clear", "reset"],

    async execute(message, args, client, prefix) {
        if (!message.member.permissions.has(PermissionsBitField.resolve("ManageGuild"))) {
            return message.reply(box(0xFFD700, `${emoji.warn} You must have \`Manage Server\` permissions to use this command.`));
        }

        const guildId = message.guild.id;
        const manager = client.autoresponder;
        if (!manager) {
            return message.reply(box(0xFFD700, `${emoji.cross} Autoresponder module failed to initialize. Check the bot logs.`));
        }

        const sub = (args[0] || "").toLowerCase();

        if (!sub) {
            const helpDisplay = new TextDisplayBuilder().setContent(
                `### ${emoji.info} Autoresponder Commands\n` +
                `> ${emoji.dot} \`${prefix}ar add <trigger> | <response>\` — exact match\n` +
                `> ${emoji.dot} \`${prefix}ar addstart <trigger> | <response>\` — message starts with trigger\n` +
                `> ${emoji.dot} \`${prefix}ar addcontains <trigger> | <response>\` — trigger anywhere as a whole word\n` +
                `> ${emoji.dot} \`${prefix}ar edit <id> <trigger> | <response>\`\n` +
                `> ${emoji.dot} \`${prefix}ar remove <id>\`\n` +
                `> ${emoji.dot} \`${prefix}ar toggle <id>\`\n` +
                `> ${emoji.dot} \`${prefix}ar list\`\n` +
                `> ${emoji.dot} \`${prefix}ar info <id>\`\n` +
                `> ${emoji.dot} \`${prefix}ar clear\`\n\n` +
                `-# Placeholders: \`{user}\`, \`{user.mention}\`, \`{user.tag}\`, \`{server}\`, \`{channel}\`.\n` +
                `-# Matching is strict — a trigger only fires on an actual match, never on unrelated chat that just happens to contain the word.`
            );
            const container = new ContainerBuilder().setAccentColor(0xFFD700).addTextDisplayComponents(helpDisplay);
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        switch (sub) {
            case "add":
            case "addstart":
            case "addcontains": {
                const matchType = sub === "add" ? "exact" : sub === "addstart" ? "startswith" : "contains";

                if (manager.maxReached(guildId)) {
                    return message.reply(box(0xFFD700, `${emoji.warn} This server already has the maximum of **50** autoresponders. Remove one first with \`${prefix}ar remove <id>\`.`));
                }

                const raw = args.slice(1).join(" ");
                const parsed = splitTriggerResponse(raw);
                if (!parsed) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`${prefix}ar ${sub} <trigger> | <response>\`\nExample: \`${prefix}ar ${sub} hello there | Hey {user}, welcome!\``));
                }

                const { trigger, response } = parsed;
                if (trigger.length > 100) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Trigger must be 100 characters or fewer.`));
                }
                if (response.length > 1500) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Response must be 1500 characters or fewer.`));
                }

                const existing = manager.getAll(guildId).find(r => r.trigger.toLowerCase() === trigger.toLowerCase() && r.matchType === matchType);
                if (existing) {
                    return message.reply(box(0xFFD700, `${emoji.warn} An autoresponder with that exact trigger and match type already exists (ID \`${existing.id}\`). Use \`${prefix}ar edit ${existing.id}\` to change it.`));
                }

                const id = client.db.autoresponder.add(guildId, {
                    trigger,
                    response,
                    matchType,
                    caseSensitive: false,
                    enabled: true,
                    createdBy: message.author.id
                });
                manager.invalidate(guildId);

                return message.reply(box(0xFFD700,
                    `${emoji.check} Autoresponder **#${id}** created.\n` +
                    `> ${emoji.dot} **Trigger:** \`${trigger}\`\n` +
                    `> ${emoji.dot} **Type:** ${MATCH_LABELS[matchType]}\n` +
                    `> ${emoji.dot} **Response:** ${response}`
                ));
            }

            case "edit": {
                const id = parseInt(args[1], 10);
                if (!Number.isFinite(id)) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`${prefix}ar edit <id> <trigger> | <response>\``));
                }

                const current = client.db.autoresponder.get(guildId, id);
                if (!current) {
                    return message.reply(box(0xFFD700, `${emoji.warn} No autoresponder found with ID \`${id}\`. Check \`${prefix}ar list\`.`));
                }

                const raw = args.slice(2).join(" ");
                const parsed = splitTriggerResponse(raw);
                if (!parsed) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`${prefix}ar edit ${id} <trigger> | <response>\``));
                }

                const { trigger, response } = parsed;
                client.db.autoresponder.update(guildId, id, { trigger, response });
                manager.invalidate(guildId);

                return message.reply(box(0xFFD700, `${emoji.check} Autoresponder **#${id}** updated.\n> ${emoji.dot} **Trigger:** \`${trigger}\`\n> ${emoji.dot} **Response:** ${response}`));
            }

            case "remove":
            case "delete": {
                const id = parseInt(args[1], 10);
                if (!Number.isFinite(id)) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`${prefix}ar remove <id>\` — see IDs with \`${prefix}ar list\`.`));
                }

                const removed = client.db.autoresponder.remove(guildId, id);
                if (!removed) {
                    return message.reply(box(0xFFD700, `${emoji.warn} No autoresponder found with ID \`${id}\`.`));
                }

                manager.invalidate(guildId);
                return message.reply(box(0xFFD700, `${emoji.check} Autoresponder **#${id}** removed.`));
            }

            case "toggle": {
                const id = parseInt(args[1], 10);
                if (!Number.isFinite(id)) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`${prefix}ar toggle <id>\``));
                }

                const current = client.db.autoresponder.get(guildId, id);
                if (!current) {
                    return message.reply(box(0xFFD700, `${emoji.warn} No autoresponder found with ID \`${id}\`.`));
                }

                client.db.autoresponder.update(guildId, id, { enabled: !current.enabled });
                manager.invalidate(guildId);

                return message.reply(box(0xFFD700, `${emoji.check} Autoresponder **#${id}** is now **${!current.enabled ? "Enabled" : "Disabled"}**.`));
            }

            case "info": {
                const id = parseInt(args[1], 10);
                if (!Number.isFinite(id)) {
                    return message.reply(box(0xFFD700, `${emoji.warn} Usage: \`${prefix}ar info <id>\``));
                }

                const current = client.db.autoresponder.get(guildId, id);
                if (!current) {
                    return message.reply(box(0xFFD700, `${emoji.warn} No autoresponder found with ID \`${id}\`.`));
                }

                return message.reply(box(0xFFD700,
                    `### ${emoji.info} Autoresponder #${current.id}\n` +
                    `> ${emoji.dot} **Trigger:** \`${current.trigger}\`\n` +
                    `> ${emoji.dot} **Match Type:** ${MATCH_LABELS[current.matchType] || current.matchType}\n` +
                    `> ${emoji.dot} **Status:** \`${current.enabled ? "Enabled" : "Disabled"}\`\n` +
                    `> ${emoji.dot} **Response:**\n${current.response}`
                ));
            }

            case "list": {
                const list = manager.getAll(guildId);
                if (!list.length) {
                    return message.reply(box(0xFFD700, `${emoji.info} This server has no autoresponders set up yet. Create one with \`${prefix}ar add <trigger> | <response>\`.`));
                }

                const lines = list.map(r =>
                    `> ${emoji.dot} \`#${r.id}\` **${r.trigger}** — ${r.enabled ? emoji.check : emoji.cross} *(${r.matchType})*`
                ).join("\n");

                return message.reply(box(0xFFD700,
                    `### ${emoji.info} Autoresponders (${list.length}/50)\n${lines}\n\n` +
                    `-# Use \`${prefix}ar info <id>\` to see the full response text.`
                ));
            }

            case "clear":
            case "reset": {
                const count = client.db.autoresponder.clear(guildId);
                manager.invalidate(guildId);

                if (!count) {
                    return message.reply(box(0xFFD700, `${emoji.info} There were no autoresponders to clear.`));
                }
                return message.reply(box(0xFFD700, `${emoji.warn} Removed all **${count}** autoresponders from this server.`));
            }

            default: {
                return message.reply(box(0xFFD700, `${emoji.warn} Unknown option. Use \`${prefix}autoresponder\` for usage info.`));
            }
        }
    }
};
