/**
 * Zyvora — UI Theme
 * ------------------------------------------------------------------
 * Central place that defines the bot's new visual identity.
 * Emojis are untouched (still pulled from src/emojis.js) — only
 * colors, accents, bullets and the progress-bar look changed here.
 */

module.exports = {
  colors: {
    primary: 0xFFD700, // main/info accent (gold)
    success: 0xFFD700, // check/confirmation accent (gold)
    error: 0xFFD700,   // cross accent (gold)
    warning: 0xFFD700, // warn accent (gold)
  },

  brand: "AxC Music",
  brandTag: "⟡ AxC Music",

  bullet: "dot",     // key into src/emojis.js — replaces the old "➤" bullet in "> ➤ **Label:**" lines
  divider: "⋆",     // small inline separator glyph used in footers

  bar: {
    line: "━",
    slider: "◉",
  },
};
