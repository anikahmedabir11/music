const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'channelCreate',
    run: async (client, channel) => {
        if (!channel.guild || !client.antinuke) return;
        await client.antinuke.handle(channel.guild, 'channelCreate', AuditLogEvent.ChannelCreate, channel.id, null, channel);
    }
};
