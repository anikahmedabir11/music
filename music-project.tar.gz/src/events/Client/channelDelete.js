const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'channelDelete',
    run: async (client, channel) => {
        if (!channel.guild || !client.antinuke) return;
        await client.antinuke.handle(channel.guild, 'channelDelete', AuditLogEvent.ChannelDelete, channel.id, null, channel);
    }
};
