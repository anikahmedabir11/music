const { Events } = require('discord.js');

module.exports = {
    name: Events.MessageReactionRemove,
    run: async (client, reaction, user) => {
        if (user.bot) return;

        const gwyEmojiId = client.emoji.gwy.match(/:(\d+)>/)?.[1];
        if (!gwyEmojiId || reaction.emoji.id !== gwyEmojiId) return;

        const giveaway = client.db.giveaways.get(reaction.message.id);
        if (!giveaway || giveaway.ended) return;

        if (giveaway.participants.includes(user.id)) {
            giveaway.participants = giveaway.participants.filter(id => id !== user.id);
            client.db.giveaways.set(reaction.message.id, giveaway);
        }
    }
};
