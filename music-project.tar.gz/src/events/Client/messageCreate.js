﻿const {
  PermissionsBitField,
  WebhookClient,
  EmbedBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  MessageFlags
} = require("discord.js");
const cooldowns = new Map();

module.exports = {
  name: "messageCreate",
  once: false,
  run: async (client, message) => {
    if (message.author.bot || !message.guild) return;

    let afkPrefix = client.prefix;
    const afkPrefixData = client.db.prefixes.get(message.guild.id);
    if (afkPrefixData?.prefix) afkPrefix = afkPrefixData.prefix;
    const isReAfkCommand = new RegExp(`^(${afkPrefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}|<@!?${client.user.id}>\\s*)afk(\\s|$)`, 'i').test(message.content.trim());

    try {
      const afkData = client.db.afk.get(message.guild.id, message.author.id);
      if (afkData && !isReAfkCommand) {
        client.db.afk.delete(message.guild.id, message.author.id);

        const mentionCount = afkData.mentions.length;
        const mentionLine = mentionCount > 0
          ? `\n> ${client.emoji.dot} **Missed pings:** ${mentionCount} while you were away`
          : '';

        const welcomeDisplay = new TextDisplayBuilder()
          .setContent(
            `### ${client.emoji.check} Welcome back, ${message.author.displayName}!\n` +
            `> ${client.emoji.dot} **You were AFK:** <t:${Math.floor(afkData.since / 1000)}:R>${mentionLine}`
          );

        const welcomeContainer = new ContainerBuilder().setAccentColor(0xFFD700)
          .addTextDisplayComponents(welcomeDisplay);

        message.channel.send({
          components: [welcomeContainer],
          flags: MessageFlags.IsComponentsV2
        }).then((msg) => {
          setTimeout(() => msg.delete().catch(() => { }), 8000);
        }).catch(() => { });
      }
    } catch (err) {
      console.error(`[AFK Error] ${err.message}`);
    }

    try {
      if (message.mentions.users.size > 0) {
        const afkMentions = [];
        for (const [id, user] of message.mentions.users) {
          if (id === message.author.id) continue;
          const mentionedAfk = client.db.afk.get(message.guild.id, id);
          if (mentionedAfk) {
            afkMentions.push({ user, afkData: mentionedAfk });
            client.db.afk.addMention(message.guild.id, id, {
              by: message.author.id,
              channelId: message.channel.id,
              timestamp: Date.now()
            });
          }
        }

        if (afkMentions.length > 0) {
          const lines = afkMentions
            .map(({ user, afkData }) => `> ${client.emoji.dot} **${user.username}** — ${afkData.reason} *(since <t:${Math.floor(afkData.since / 1000)}:R>)*`)
            .join('\n');

          const mentionDisplay = new TextDisplayBuilder()
            .setContent(`### ${client.emoji.info} AFK Notice\n${lines}`);

          const mentionContainer = new ContainerBuilder().setAccentColor(0xFFD700)
            .addTextDisplayComponents(mentionDisplay);

          message.channel.send({
            components: [mentionContainer],
            flags: MessageFlags.IsComponentsV2
          }).catch(() => { });
        }
      }
    } catch (err) {
      console.error(`[AFK Mention Error] ${err.message}`);
    }

    try {
      if (client.automod) client.automod.handleMessage(message);
    } catch (err) {
      console.error(`[AutoMod Error] ${err.message}`);
    }

    const isIgnored = client.db.ignorechannels.get(message.guild.id, message.channel.id);
    if (isIgnored) {
      return;
    }

    try {
      if (client.autoresponder) await client.autoresponder.handleMessage(message);
    } catch (err) {
      console.error(`[Autoresponder Error] ${err.message}`);
    }



    let prefix = client.prefix;
    const prefixData = client.db.prefixes.get(message.guild.id);
    if (prefixData?.prefix) prefix = prefixData.prefix;

    const mention = new RegExp(`^<@!?${client.user.id}>( |)$`);
    if (message.content.match(mention)) {
      const perms = message.channel.permissionsFor(client.user);
      if (!perms || !perms.has(PermissionsBitField.Flags.SendMessages) || !perms.has(PermissionsBitField.Flags.EmbedLinks)) {
        return;
      }

      const greetDisplay = new TextDisplayBuilder()
        .setContent(
          `**${client.emoji.check} Hey ${message.author}!**\n` +
          `**${client.emoji.info} My prefix for this server is  **\`${prefix}\`\n\n` +
          `**${client.emoji.info} Type \`${prefix}help\` for a list of commands.**`
        );

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(greetDisplay);

      await message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => null);
      return;
    }

    const hasNoPrefix = client.db.noprefix.getGlobal(message.author.id);

    let usedPrefix = '';
    if (message.content.startsWith(prefix)) {
      usedPrefix = prefix;
    } else if (message.content.match(new RegExp(`^<@!?${client.user.id}>`))) {
      usedPrefix = message.content.match(new RegExp(`^<@!?${client.user.id}>`))[0];
    } else if (!hasNoPrefix) {
      return;
    }

    const args = message.content.slice(usedPrefix.length).trim().split(/ +/);
    const commandName = args.shift()?.toLowerCase();
    if (!commandName) return;

    const command = client.commands.get(commandName)
      || client.commands.find(cmd => Array.isArray(cmd.aliases) ? cmd.aliases.includes(commandName) : cmd.aliases === commandName);

    if (!command) return;

    // When there's no explicit prefix (no-prefix mode) or the invocation is a
    // bare mention, a message is just plain chat that happens to start with a
    // word that matches a command/alias name. Only treat it as a real command
    // call when the usage that follows actually looks like a valid, complete
    // invocation — otherwise ignore it so the bot doesn't fire (or dump a full
    // help embed) on ordinary sentences like "antinuke sahi hai".
    if (usedPrefix.length === 0) {
      if (commandName === 'i' && command.name === 'invites') {
        if (args.length > 1 || (args.length === 1 && !/^(<@!?\d+>|\d+)$/.test(args[0]))) {
          return;
        }
      }

      if (Array.isArray(command.subCommands) && command.subCommands.length && args.length) {
        const firstArg = args[0].toLowerCase();
        const validSub = command.subCommands.some(sc => sc.toLowerCase() === firstArg);
        if (!validSub) return;
      }
    }

    const isBlacklisted = client.db.blacklist.get(message.author.id);
    if (isBlacklisted) {
      const blacklistDisplay = new TextDisplayBuilder()
        .setContent(`**${client.emoji.warn} You have been blacklisted from using the bot!**`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(blacklistDisplay);

      const reply = await message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => null);
      if (reply) setTimeout(() => reply.delete().catch(() => { }), 5000);
      return;
    }

    if (!cooldowns.has(command.name)) {
      cooldowns.set(command.name, new Map());
    }

    const now = Date.now();
    const timestamps = cooldowns.get(command.name);
    const cooldownAmount = (command.cooldown || 3) * 1000;

    if (timestamps.has(message.author.id)) {
      const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

      if (now < expirationTime) {
        const timeLeft = ((expirationTime - now) / 1000).toFixed(1);

        const cooldownDisplay = new TextDisplayBuilder()
          .setContent(`**${client.emoji.warn} Please wait ${timeLeft}s before using \`${command.name}\` command again.**`);

        const container = new ContainerBuilder().setAccentColor(0xFFD700)
          .addTextDisplayComponents(cooldownDisplay);

        return message.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2
        }).then((msg) => {
          const delayTime = expirationTime - now;
          setTimeout(() => {
            msg.delete().catch(() => { });
          }, delayTime);
        });
      }
    }
    timestamps.set(message.author.id, now);
    setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

    const perms = message.channel.permissionsFor(client.user);
    if (!perms || !perms.has(PermissionsBitField.Flags.SendMessages)) {
      const errorDisplay = new TextDisplayBuilder()
        .setContent(`**${client.emoji.cross} I don't have \`SEND_MESSAGES\` permission in this channel to execute the \`${command.name}\` command.**`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(errorDisplay);

      return await message.author.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => { });
    }

    if (!perms.has(PermissionsBitField.Flags.EmbedLinks)) {
      const errorDisplay = new TextDisplayBuilder()
        .setContent(`**${client.emoji.cross} I don't have \`EMBED_LINKS\` permission in this channel to execute the \`${command.name}\` command.**`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(errorDisplay);

      return await message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => { });
    }

    if (command.args && !args.length) {
      let reply = `You didn't provide any arguments, ${message.author}!`;
      if (command.usage) {
        reply += `\nUsage: \`${prefix}${command.name} ${command.usage}\``;
      }

      const argsDisplay = new TextDisplayBuilder()
        .setContent(reply);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(argsDisplay);

      return message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => null);
    }

    if (command.botPerms && !message.guild.members.me.permissions.has(PermissionsBitField.resolve(command.botPerms || []))) {
      const permDisplay = new TextDisplayBuilder()
        .setContent(`I need the **\`${command.botPerms.join(', ')}\`** permission(s) to execute this command.`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(permDisplay);

      return message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => null);
    }

    if (command.userPerms && !client.config.ownerID.includes(message.author.id) && !message.member.permissions.has(PermissionsBitField.resolve(command.userPerms || []))) {
      const permDisplay = new TextDisplayBuilder()
        .setContent(`You need the **\`${command.userPerms.join(', ')}\`** permission(s) to use this command.`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(permDisplay);

      return message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => null);
    }

    const { checkBotRank } = require("../../utils/permissionCheck");
    if (command.rank) {
      const hasRank = await checkBotRank(message.author.id, command.rank, client, command.name);
      if (!hasRank) return;
    } else if (command.owner && !client.config.ownerID.includes(message.author.id)) {
      return;
    }

    const player = client.manager.players.get(message.guild.id);
    if (command.player && !player) {
      const playerDisplay = new TextDisplayBuilder()
        .setContent(`**${client.emoji.warn} There is no music player active in this server.**`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(playerDisplay);

      return message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => null);
    }

    if (command.inVoiceChannel && !message.member.voice.channel) {
      const vcDisplay = new TextDisplayBuilder()
        .setContent(`**${client.emoji.warn} You must be in a voice channel to use this command.**`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(vcDisplay);

      return message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => null);
    }

    if (command.sameVoiceChannel && player && message.member.voice.channel.id !== player.voiceId) {
      const sameVcDisplay = new TextDisplayBuilder()
        .setContent(`**${client.emoji.warn} You must be in the same voice channel as me.**`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(sameVcDisplay);

      return message.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => null);
    }

    try {
      await command.execute(message, args, client, prefix);

      if (client.config.Webhooks?.cmdrun) {
        const web = new WebhookClient({ url: client.config.Webhooks.cmdrun });

        const commandlog = new EmbedBuilder()
          .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setColor(client.color)
          .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
          .setTimestamp()
          .setDescription(
            `**${client.emoji.dot} Command Used In:** \`${message.guild.name} | ${message.guild.id}\`\n` +
            `**${client.emoji.dot} Channel:** \`${message.channel.name} | ${message.channel.id}\`\n` +
            `**${client.emoji.dot} Command:** \`${command.name}\`\n` +
            `**${client.emoji.dot} Executor:** \`${message.author.tag} | ${message.author.id}\`\n` +
            `**${client.emoji.dot} Content:** \`${message.content}\``
          );

        web.send({ embeds: [commandlog] }).catch(console.error);
      }
    } catch (error) {
      console.error(`Error executing command ${command.name}:`, error);

      const errorDisplay = new TextDisplayBuilder()
        .setContent(`**${client.emoji.warn} An error occurred while executing this command!**`);

      const container = new ContainerBuilder().setAccentColor(0xFFD700)
        .addTextDisplayComponents(errorDisplay);

      try {
        const perms = message.channel.permissionsFor(client.user);
        if (perms && perms.has(PermissionsBitField.Flags.SendMessages)) {
          if (perms.has(PermissionsBitField.Flags.EmbedLinks)) {
            await message.channel.send({
              components: [container],
              flags: MessageFlags.IsComponentsV2
            });
          } else {
            await message.channel.send({
              content: `**${client.emoji.warn} An error occurred while executing this command!**`
            });
          }
        }
      } catch (sendError) {
        if (sendError.code !== 50013) {
          console.error(`Failed to send error message:`, sendError);
        }
      }
    }
  },
};
