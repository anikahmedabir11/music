const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildBanAdd',
    run: async (client, ban) => {
        if (!ban.guild || !client.antinuke) return;
        await client.antinuke.handle(ban.guild, 'massBan', AuditLogEvent.MemberBanAdd, ban.user?.id, null, ban);
    }
};
