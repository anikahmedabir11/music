module.exports = {
    name: 'guildAuditLogEntryCreate',
    run: async (client, auditLogEntry, guild) => {
        if (!guild || !client.antinuke) return;
        // Discord pushes this the instant an audit log entry is created — no
        // REST call needed. This is what feeds AntiNuke's instant detection path.
        client.antinuke.onAuditLogEntry(guild, auditLogEntry);
    }
};
