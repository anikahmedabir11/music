const {
  WebhookClient,
  EmbedBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
  AuditLogEvent
} = require("discord.js");
const config = require("../../config.js");
const {
  Webhooks: { guild_join },
  links: { support }
} = config;

const moment = require("moment");

module.exports = {
  name: "guildCreate",
  run: async (client, guild) => {
    const web = new WebhookClient({ url: guild_join });
    const own = await guild.fetchOwner().catch(() => null);

    const vanity = guild.vanityURLCode
      ? `[**Invite Link**](https://discord.gg/${guild.vanityURLCode})`
      : `\`No vanity URL\``;

    const embed = new EmbedBuilder()
      .setColor(client.color)
      .setThumbnail(guild.iconURL({ size: 1024 }))
      .setDescription(
        `**${client.emoji.check} Joined a Guild**\n\n` +
        `**${client.emoji.dot} Server Name:** \`${guild.name}\` \n` +
        `**${client.emoji.dot} Server ID:** \`${guild.id}\` \n` +
        `**${client.emoji.dot} Server Owner:** \`${own?.user?.username || "Unknown"}\` (${own?.id || "N/A"}) \n` +
        `**${client.emoji.dot} Member Count:** \`${guild.memberCount}\` Members \n` +
        `**${client.emoji.dot} Creation Date:** \`${moment.utc(guild.createdAt).format("DD/MMM/YYYY")}\` \n` +
        `**${client.emoji.dot} Guild Invite:** ${vanity} \n` +
        `**${client.emoji.dot} Total Servers:** \`${client.guilds.cache.size}\``
      )
      .setFooter({
        text: `Total Server Count [ ${client.guilds.cache.size} ]`,
        iconURL: client.user.displayAvatarURL(),
      })
      .setTimestamp();

    web.send({ embeds: [embed] }).catch(() => { });

    const giveawayManager = require("../../utils/giveawayManager");
    await giveawayManager.syncGiveaways(client, guild);

    try {
      if (own && own.user) {
        const recipient = own.user;

        const guildPrefixEntry = client.db?.prefixes?.get?.(guild.id);
        const usedPrefix = guildPrefixEntry?.prefix || client.prefix;
        const commandCount = client.commands ? client.commands.size : 0;
        const invite = config.links?.invite || support;

        const welcomeHeader = new TextDisplayBuilder()
          .setContent(`### ${client.emoji.check} Thank you for adding **${client.user.username}** to \`${guild.name}\`.`);

        const separator1 = new SeparatorBuilder();

        const introDisplay = new TextDisplayBuilder()
          .setContent(
            `${client.user.username} is a multipurpose Discord bot with over **${commandCount}** commands, ` +
            `covering music, moderation, automod, antinuke protection, tickets and more, aimed at making your Discord experience seamless, hassle-free and fun. ` +
            `We are committed to resolving any issues that you face, instead of removing the bot, please [contact our support server](${support}) to receive further help.`
          );

        const separator2 = new SeparatorBuilder();

        const prefixDisplay = new TextDisplayBuilder()
          .setContent(
            `**${client.user.username}'s default prefix is set to:** \`${usedPrefix}\`  If you would like to change this prefix, simply run \`${usedPrefix}setprefix (prefix)\` and **ensure** that the bot has the necessary permissions.`
          );

        const separator3 = new SeparatorBuilder();

        const quickStartHeader = new TextDisplayBuilder()
          .setContent(`**Quick Start Guide:**`);

        const quickStartDisplay = new TextDisplayBuilder()
          .setContent(
            `\`${usedPrefix}play (song)\` — Plays music in your voice channel\n` +
            `\`${usedPrefix}automod enable\` — Turns on automod to keep chat clean\n` +
            `\`${usedPrefix}antinuke enable\` — Protects your server from raids and nukes\n` +
            `\`${usedPrefix}ticket setup\` — Sets up a support ticket system\n` +
            `\`${usedPrefix}welcome channel\` — Configures member welcome messages`
          );

        const separator4 = new SeparatorBuilder();

        const supportButton = new ButtonBuilder()
          .setLabel('Support Server')
          .setStyle(ButtonStyle.Link)
          .setURL(support);

        const inviteButton = new ButtonBuilder()
          .setLabel('Invite Link')
          .setStyle(ButtonStyle.Link)
          .setURL(invite);

        const buttonRow = new ActionRowBuilder()
          .addComponents(supportButton, inviteButton);

        const containerColor = typeof client.color === 'string' && client.color.startsWith('#') 
          ? parseInt(client.color.replace('#', ''), 16) 
          : (typeof client.color === 'number' ? client.color : 0x8A5CFF);

        const container = new ContainerBuilder().setAccentColor(containerColor)
          .addTextDisplayComponents(welcomeHeader)
          .addSeparatorComponents(separator1)
          .addTextDisplayComponents(introDisplay)
          .addSeparatorComponents(separator2)
          .addTextDisplayComponents(prefixDisplay)
          .addSeparatorComponents(separator3)
          .addTextDisplayComponents(quickStartHeader)
          .addTextDisplayComponents(quickStartDisplay)
          .addSeparatorComponents(separator4)
          .addActionRowComponents(buttonRow);

        await recipient.send({
          components: [container],
          flags: MessageFlags.IsComponentsV2
        }).catch((err) => {
          console.log(`Could not send welcome DM to ${recipient.username}: ${err.message}`);
        });
      }
    } catch (error) {
      console.error('Error sending welcome DM:', error);
    }
  },
};
