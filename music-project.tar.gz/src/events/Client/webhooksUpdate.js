const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'webhooksUpdate',
    run: async (client, channel) => {
        if (!channel.guild || !client.antinuke) return;
        await client.antinuke.handle(channel.guild, 'webhookCreate', AuditLogEvent.WebhookCreate);
    }
};
