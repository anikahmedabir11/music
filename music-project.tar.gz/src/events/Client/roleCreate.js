const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'roleCreate',
    run: async (client, role) => {
        if (!role.guild || !client.antinuke) return;
        await client.antinuke.handle(role.guild, 'roleCreate', AuditLogEvent.RoleCreate, role.id);
    }
};
