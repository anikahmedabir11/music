const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'roleDelete',
    run: async (client, role) => {
        if (!role.guild || !client.antinuke) return;
        await client.antinuke.handle(role.guild, 'roleDelete', AuditLogEvent.RoleDelete, role.id);
    }
};
