const path = require('path');

const jsonConfig = path.join(__dirname, 'config.json');

let config;
try {
  config = require(jsonConfig);
} catch (err) {
  console.error("❌ config.json not found or is invalid!", err.message);
  process.exit(1);
}

function parseBoolean(value) {
  if (typeof value === "string") {
    value = value.trim().toLowerCase();
  }
  switch (value) {
    case true:
    case "true":
      return true;
    default:
      return false;
  }
}

config.parseBoolean = parseBoolean;

// Load token from environment variable if available to prevent leaking on GitHub
config.token = process.env.TOKEN || process.env.DISCORD_TOKEN || config.token;
config.clientSecret = process.env.DISCORD_CLIENT_SECRET || process.env.CLIENT_SECRET || config.clientSecret;
config.mongoUri = process.env.MONGO_URI || process.env.MONGO_URL || config.mongoUri;

module.exports = config;
