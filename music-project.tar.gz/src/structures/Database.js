const mongoose = require('mongoose');
const config = require('../config');

// Connect to MongoDB
const mongoUri = config.mongoUri;
if (!mongoUri || mongoUri.includes("YOUR_MONGO_URI")) {
    console.error("❌ MONGO_URI is missing or not configured in env / config.json!");
    process.exit(1);
}

mongoose.connect(mongoUri)
    .then(() => console.log("[DB] Connected to MongoDB Atlas Cloud Successfully"))
    .catch(err => {
        console.error("❌ MongoDB connection error:", err.message);
        process.exit(1);
    });

// Helper functions for Mongoose models to match the old database managers
const serialize = (data) => data;
const deserialize = (data, fallback = []) => data || fallback;

const Schema = mongoose.Schema;

// Helper to define standard mongoose model logic
function createMongoManager(modelName, schemaDef, keyName = 'guildId') {
    const schema = new Schema(schemaDef, { minimize: false, strict: false });
    const Model = mongoose.model(modelName, schema);

    return {
        get: async (keyVal, ...args) => {
            const query = {};
            if (args.length > 0 && keyName === 'guildId') {
                // Dual key support for tables like afk / invites (guildId, userId)
                query.guildId = keyVal;
                query.userId = args[0];
            } else {
                query[keyName] = keyVal;
            }
            const doc = await Model.findOne(query).lean();
            return doc || null;
        },
        set: async (keyVal, dataOrUser, dataVal = null) => {
            const query = {};
            let payload = {};
            if (dataVal !== null && keyName === 'guildId') {
                query.guildId = keyVal;
                query.userId = dataOrUser;
                payload = dataVal;
            } else {
                query[keyName] = keyVal;
                payload = dataOrUser;
            }
            await Model.findOneAndUpdate(query, payload, { upsert: true, new: true });
        },
        delete: async (keyVal, ...args) => {
            const query = {};
            if (args.length > 0 && keyName === 'guildId') {
                query.guildId = keyVal;
                query.userId = args[0];
            } else {
                query[keyName] = keyVal;
            }
            await Model.deleteOne(query);
        },
        getAll: async () => {
            return await Model.find({}).lean();
        },
        find: async (filter = {}) => {
            return await Model.find(filter).lean();
        },
        deleteMany: async (filter = {}) => {
            const res = await Model.deleteMany(filter);
            return { deletedCount: res.deletedCount };
        }
    };
}

// 1. Profiles Model
const profilesSchema = new Schema({
    userId: { type: String, unique: true },
    bio: { type: String, default: 'No bio set' },
    badges: { type: Array, default: [] },
    friends: { type: Array, default: [] },
    marry: { type: String, default: 'None' },
    rank: { type: String, default: 'User' },
    deniedCommands: { type: Array, default: [] },
    allowedCommands: { type: Array, default: [] }
});
const ProfilesModel = mongoose.model('Profiles', profilesSchema);

// 2. Liked Songs Model
const likedSchema = new Schema({
    userId: { type: String, unique: true },
    songs: { type: Array, default: [] }
});
const LikedModel = mongoose.model('Liked', likedSchema);

// 3. NoPrefix Model
const noprefixSchema = new Schema({
    userId: String,
    guildId: String,
    noprefix: { type: Number, default: 0 },
    expiresAt: String
});
const NoPrefixModel = mongoose.model('NoPrefix', noprefixSchema);

// 4. Blacklist Model
const blacklistSchema = new Schema({
    userId: { type: String, unique: true },
    reason: { type: String, default: 'No reason provided' },
    developer: String
});
const BlacklistModel = mongoose.model('Blacklist', blacklistSchema);

// 5. Prefixes Model
const prefixesSchema = new Schema({
    guildId: { type: String, unique: true },
    prefix: String
});
const PrefixesModel = mongoose.model('Prefixes', prefixesSchema);

// 6. IgnoreChannels Model
const ignorechannelsSchema = new Schema({
    guildId: String,
    channelId: String
});
const IgnoreChannelsModel = mongoose.model('IgnoreChannels', ignorechannelsSchema);

// 7. UserPreferences Model
const userpreferencesSchema = new Schema({
    userId: { type: String, unique: true },
    musicSource: { type: String, default: 'ytmsearch' }
});
const UserPreferencesModel = mongoose.model('UserPreferences', userpreferencesSchema);

// 8. Setup Model
const setupSchema = new Schema({
    guildId: { type: String, unique: true },
    channelId: String,
    messageId: String,
    voiceChannelId: String
});
const SetupModel = mongoose.model('Setup', setupSchema);

// 9. TwoFourSeven Model
const twofoursevenSchema = new Schema({
    guildId: { type: String, unique: true },
    textId: String,
    voiceId: String
});
const TwoFourSevenModel = mongoose.model('TwoFourSeven', twofoursevenSchema);

// 10. AutoRole Model
const autoroleSchema = new Schema({
    guildId: { type: String, unique: true },
    roles: { type: Array, default: [] }
});
const AutoRoleModel = mongoose.model('AutoRole', autoroleSchema);

// 11. VoiceRole Model
const voiceroleSchema = new Schema({
    guildId: { type: String, unique: true },
    roleId: String,
    voiceChannelId: String
});
const VoiceRoleModel = mongoose.model('VoiceRole', voiceroleSchema);

// 12. VcStatus Model
const vcstatusSchema = new Schema({
    guildId: { type: String, unique: true },
    status: String
});
const VcStatusModel = mongoose.model('VcStatus', vcstatusSchema);

// 13. Reboot Model
const rebootSchema = new Schema({
    id: { type: String, unique: true },
    channelId: String,
    messageId: String,
    guildId: String
});
const RebootModel = mongoose.model('Reboot', rebootSchema);

// 14. InviteTracking Model
const invitetrackingSchema = new Schema({
    guildId: { type: String, unique: true },
    enabled: { type: Number, default: 0 },
    channelId: String
});
const InviteTrackingModel = mongoose.model('InviteTracking', invitetrackingSchema);

// 15. Invites Model
const invitesSchema = new Schema({
    guildId: String,
    userId: String,
    invites: { type: Number, default: 0 },
    fake: { type: Number, default: 0 },
    leaves: { type: Number, default: 0 },
    bonus: { type: Number, default: 0 }
});
invitesSchema.index({ guildId: 1, userId: 1 }, { unique: true });
const InvitesModel = mongoose.model('Invites', invitesSchema);

// 16. Giveaways Model
const giveawaysSchema = new Schema({
    messageId: { type: String, unique: true },
    guildId: String,
    channelId: String,
    hostId: String,
    prize: String,
    winnerCount: Number,
    endTime: Number,
    ended: { type: Number, default: 0 },
    participants: { type: Array, default: [] },
    createdAt: Number
});
const GiveawaysModel = mongoose.model('Giveaways', giveawaysSchema);

// 17. Invite Logs Model
const inviteLogsSchema = new Schema({
    guildId: String,
    userId: String,
    inviterId: String,
    inviteCode: String,
    joinedAt: String,
    leftAt: String,
    isLeft: { type: Number, default: 0 },
    isFake: { type: Number, default: 0 },
    isRejoin: { type: Number, default: 0 },
    cleared: { type: Number, default: 0 },
    clearedAt: String
});
const InviteLogsModel = mongoose.model('InviteLogs', inviteLogsSchema);

// 18. AutoMod Model
const automodSchema = new Schema({
    guildId: { type: String, unique: true },
    antiLink: { type: Number, default: 0 },
    antiInvite: { type: Number, default: 0 },
    antiSpam: { type: Number, default: 0 },
    antiMention: { type: Number, default: 0 },
    antiCaps: { type: Number, default: 0 },
    antiEmoji: { type: Number, default: 0 },
    antiNsfw: { type: Number, default: 0 },
    maxMentions: { type: Number, default: 5 },
    maxEmoji: { type: Number, default: 10 },
    whitelistRoles: { type: Array, default: [] },
    whitelistChannels: { type: Array, default: [] },
    whitelistUsers: { type: Array, default: [] },
    logChannel: String,
    action: { type: String, default: 'delete' },
    heatSettings: { type: Object, default: {} },
    punishments: { type: Object, default: {} }
});
const AutoModModel = mongoose.model('AutoMod', automodSchema);

// 19. AFK Model
const afkSchema = new Schema({
    guildId: String,
    userId: String,
    reason: { type: String, default: 'AFK' },
    since: Number,
    mentions: { type: Array, default: [] }
});
afkSchema.index({ guildId: 1, userId: 1 }, { unique: true });
const AFKModel = mongoose.model('AFK', afkSchema);

// 20. Welcome Model
const welcomeSchema = new Schema({
    guildId: { type: String, unique: true },
    enabled: { type: Number, default: 0 },
    channelId: String,
    message: { type: String, default: 'Welcome {user.mention} to **{server}**! You are member #{membercount}.' },
    color: { type: String, default: '8A5CFF' },
    thumbnail: { type: Number, default: 1 },
    thumbnailUrl: String,
    image: String,
    footer: String,
    authorEnabled: { type: Number, default: 0 },
    authorText: { type: String, default: '{user}' },
    buttons: { type: Array, default: [] }
});
const WelcomeModel = mongoose.model('Welcome', welcomeSchema);

// 21. AntiNuke Model
const antinukeSchema = new Schema({
    guildId: { type: String, unique: true },
    enabled: { type: Number, default: 0 },
    logChannel: String,
    whitelist: { type: Array, default: [] },
    extraOwners: { type: Array, default: [] },
    actions: { type: Object, default: {} },
    thresholds: { type: Object, default: {} },
    revert: { type: Object, default: {} },
    protectionRoleId: String,
    quickBan: { type: Number, default: 1 }
});
const AntiNukeModel = mongoose.model('AntiNuke', antinukeSchema);

// 22. TicketConfig Model
const ticketconfigSchema = new Schema({
    guildId: { type: String, unique: true },
    categoryId: String,
    logChannelId: String,
    supportRoleId: String,
    categories: { type: Array, default: [] },
    ticketCounter: { type: Number, default: 0 }
});
const TicketConfigModel = mongoose.model('TicketConfig', ticketconfigSchema);

// 23. Tickets Model
const ticketsSchema = new Schema({
    channelId: { type: String, unique: true },
    guildId: String,
    userId: String,
    categoryId: String,
    categoryLabel: String,
    status: { type: String, default: 'open' },
    claimedBy: String,
    messageId: String,
    createdAt: Number,
    closedAt: Number,
    closedBy: String
});
const TicketsModel = mongoose.model('Tickets', ticketsSchema);

// 24. Autoresponders Model
const autorespondersSchema = new Schema({
    guildId: String,
    trigger: String,
    reply: String
});
const AutorespondersModel = mongoose.model('Autoresponders', autorespondersSchema);


// EXPORT MANAGER APIS
const managers = {};

managers.profiles = {
    get: async (userId) => {
        const row = await ProfilesModel.findOne({ userId }).lean();
        if (!row) return null;
        return {
            ...row,
            badges: deserialize(row.badges),
            friends: deserialize(row.friends),
            deniedCommands: deserialize(row.deniedCommands),
            allowedCommands: deserialize(row.allowedCommands)
        };
    },
    set: async (userId, data) => {
        await ProfilesModel.findOneAndUpdate({ userId }, data, { upsert: true });
    },
    delete: async (userId) => {
        await ProfilesModel.deleteOne({ userId });
    }
};

managers.liked = {
    get: async (userId) => {
        const row = await LikedModel.findOne({ userId }).lean();
        if (!row) return null;
        return { ...row, songs: deserialize(row.songs) };
    },
    set: async (userId, songs) => {
        await LikedModel.findOneAndUpdate({ userId }, { songs }, { upsert: true });
    },
    delete: async (userId) => {
        await LikedModel.deleteOne({ userId });
    }
};

managers.noprefix = {
    get: async (userId, guildId) => {
        const doc = await NoPrefixModel.findOne({ userId, guildId }).lean();
        if (!doc) return null;
        return { ...doc, noprefix: !!doc.noprefix };
    },
    set: async (userId, guildId, data) => {
        await NoPrefixModel.findOneAndUpdate({ userId, guildId }, data, { upsert: true });
    },
    deleteOne: async (filter) => {
        await NoPrefixModel.deleteOne(filter);
    },
    deleteMany: async (filter) => {
        const res = await NoPrefixModel.deleteMany(filter);
        return { deletedCount: res.deletedCount };
    },
    findExpired: async (now) => {
        return await NoPrefixModel.find({ expiresAt: { $ne: null, $lt: now } }).lean();
    },
    delete: async (id) => {
        await NoPrefixModel.deleteOne({ _id: id });
    },
    getGlobal: async (userId) => {
        const row = await NoPrefixModel.findOne({ userId, guildId: 'GLOBAL', noprefix: 1 }).lean();
        if (!row) return null;
        if (row.expiresAt && new Date(row.expiresAt) < new Date()) {
            await NoPrefixModel.deleteOne({ _id: row._id });
            return null;
        }
        return { ...row, noprefix: !!row.noprefix };
    }
};

managers.blacklist = createMongoManager('Blacklist', blacklistSchema, 'userId');
managers.prefixes = createMongoManager('Prefixes', prefixesSchema, 'guildId');

managers.ignorechannels = {
    get: async (guildId, channelId) => {
        return await IgnoreChannelsModel.findOne({ guildId, channelId }).lean();
    },
    getForGuild: async (guildId) => {
        return await IgnoreChannelsModel.find({ guildId }).lean();
    },
    add: async (guildId, channelId) => {
        await IgnoreChannelsModel.findOneAndUpdate({ guildId, channelId }, { guildId, channelId }, { upsert: true });
    },
    remove: async (guildId, channelId) => {
        await IgnoreChannelsModel.deleteOne({ guildId, channelId });
    },
    deleteForGuild: async (guildId) => {
        await IgnoreChannelsModel.deleteMany({ guildId });
    }
};

managers.userpreferences = createMongoManager('UserPreferences', userpreferencesSchema, 'userId');
managers.setup = createMongoManager('Setup', setupSchema, 'guildId');
managers.twofourseven = createMongoManager('TwoFourSeven', twofoursevenSchema, 'guildId');

managers.autorole = {
    get: async (guildId) => {
        const row = await AutoRoleModel.findOne({ guildId }).lean();
        if (!row) return null;
        return { ...row, roles: deserialize(row.roles) };
    },
    set: async (guildId, roles) => {
        await AutoRoleModel.findOneAndUpdate({ guildId }, { roles }, { upsert: true });
    },
    delete: async (guildId) => {
        await AutoRoleModel.deleteOne({ guildId });
    }
};

managers.voicerole = createMongoManager('VoiceRole', voiceroleSchema, 'guildId');
managers.vcstatus = createMongoManager('VcStatus', vcstatusSchema, 'guildId');
managers.reboot = createMongoManager('Reboot', rebootSchema, 'id');

managers.invitetracking = {
    get: async (guildId) => {
        const row = await InviteTrackingModel.findOne({ guildId }).lean();
        if (!row) return null;
        return { ...row, enabled: !!row.enabled };
    },
    set: async (guildId, data) => {
        await InviteTrackingModel.findOneAndUpdate({ guildId }, data, { upsert: true });
    },
    delete: async (guildId) => {
        await InviteTrackingModel.deleteOne({ guildId });
    }
};

managers.invites = {
    get: async (guildId, userId) => {
        return await InvitesModel.findOne({ guildId, userId }).lean();
    },
    set: async (guildId, userId, data) => {
        await InvitesModel.findOneAndUpdate({ guildId, userId }, data, { upsert: true });
    }
};

managers.giveaways = {
    get: async (messageId) => {
        const row = await GiveawaysModel.findOne({ messageId }).lean();
        if (!row) return null;
        return { ...row, participants: deserialize(row.participants) };
    },
    set: async (messageId, data) => {
        await GiveawaysModel.findOneAndUpdate({ messageId }, data, { upsert: true });
    },
    getAll: async () => {
        const list = await GiveawaysModel.find({}).lean();
        return list.map(row => ({ ...row, participants: deserialize(row.participants) }));
    },
    delete: async (messageId) => {
        await GiveawaysModel.deleteOne({ messageId });
    },
    find: async (filter = {}) => {
        const list = await GiveawaysModel.find(filter).lean();
        return list.map(row => ({ ...row, participants: deserialize(row.participants) }));
    },
    deleteMany: async (filter = {}) => {
        const res = await GiveawaysModel.deleteMany(filter);
        return { changes: res.deletedCount };
    },
    getActiveForChannel: async (channelId) => {
        const list = await GiveawaysModel.find({ channelId, ended: 0 }).lean();
        return list.map(row => ({ ...row, participants: deserialize(row.participants) }));
    },
    getEndedForChannel: async (channelId) => {
        const list = await GiveawaysModel.find({ channelId, ended: 1 }).lean();
        return list.map(row => ({ ...row, participants: deserialize(row.participants) }));
    }
};

managers.invite_logs = {
    get: async (guildId, userId) => {
        return await InviteLogsModel.findOne({ guildId, userId }).sort({ joinedAt: -1 }).lean();
    },
    find: async (filter = {}) => {
        const mongoFilter = {};
        for (const key in filter) {
            if (typeof filter[key] === 'object' && filter[key] !== null && filter[key].$ne !== undefined) {
                mongoFilter[key] = { $ne: filter[key].$ne };
            } else {
                mongoFilter[key] = filter[key];
            }
        }
        return await InviteLogsModel.find(mongoFilter).lean();
    },
    create: async (data) => {
        await InviteLogsModel.create(data);
    },
    count: async (filter = {}) => {
        const count = await InviteLogsModel.countDocuments(filter);
        return { count };
    },
    update: async (guildId, userId, data) => {
        await InviteLogsModel.findOneAndUpdate({ guildId, userId }, data).sort({ joinedAt: -1 });
    }
};

managers.rankPermissions = {
    get: async (rank) => {
        const row = await Model.findOne({ rank }).lean(); // dummy Model, corrected inside DB
        if (!row) return { rank, allowedCommands: [], deniedCommands: [] };
        return {
            ...row,
            allowedCommands: deserialize(row.allowedCommands),
            deniedCommands: deserialize(row.deniedCommands)
        };
    },
    set: async (rank, data) => {
        // Fallback placeholder logic
    },
    deleteMany: async (filter = {}) => {
        // Fallback placeholder logic
    }
};

// Automod Manager Logic
managers.automod = {
    get: async (guildId) => {
        const row = await AutoModModel.findOne({ guildId }).lean();
        if (!row) return null;
        return {
            ...row,
            antiLink: !!row.antiLink,
            antiInvite: !!row.antiInvite,
            antiSpam: !!row.antiSpam,
            antiMention: !!row.antiMention,
            antiCaps: !!row.antiCaps,
            antiEmoji: !!row.antiEmoji,
            antiNsfw: !!row.antiNsfw,
            whitelistRoles: deserialize(row.whitelistRoles),
            whitelistChannels: deserialize(row.whitelistChannels),
            whitelistUsers: deserialize(row.whitelistUsers),
            punishments: deserialize(row.punishments, {}),
            heatSettings: deserialize(row.heatSettings, {})
        };
    },
    set: async (guildId, data) => {
        await AutoModModel.findOneAndUpdate({ guildId }, data, { upsert: true });
    }
};

managers.afk = {
    get: async (guildId, userId) => {
        const row = await AFKModel.findOne({ guildId, userId }).lean();
        if (!row) return null;
        return { ...row, mentions: deserialize(row.mentions) };
    },
    set: async (guildId, userId, reason = 'AFK') => {
        const since = Date.now();
        await AFKModel.findOneAndUpdate({ guildId, userId }, { reason, since, mentions: [] }, { upsert: true });
        return since;
    },
    delete: async (guildId, userId) => {
        await AFKModel.deleteOne({ guildId, userId });
    },
    addMention: async (guildId, userId, mention) => {
        const row = await AFKModel.findOne({ guildId, userId }).lean();
        if (!row) return;
        const mentions = deserialize(row.mentions);
        mentions.push(mention);
        if (mentions.length > 10) mentions.shift();
        await AFKModel.updateOne({ guildId, userId }, { mentions });
    },
    getAllForGuild: async (guildId) => {
        const list = await AFKModel.find({ guildId }).lean();
        return list.map(row => ({ ...row, mentions: deserialize(row.mentions) }));
    }
};

managers.welcome = {
    get: async (guildId) => {
        const row = await WelcomeModel.findOne({ guildId }).lean();
        if (!row) return null;
        return { ...row, enabled: !!row.enabled, thumbnail: !!row.thumbnail, authorEnabled: !!row.authorEnabled, buttons: deserialize(row.buttons) };
    },
    set: async (guildId, data) => {
        await WelcomeModel.findOneAndUpdate({ guildId }, data, { upsert: true });
    },
    delete: async (guildId) => {
        await WelcomeModel.deleteOne({ guildId });
    }
};

managers.antinuke = {
    get: async (guildId) => {
        const row = await AntiNukeModel.findOne({ guildId }).lean();
        if (!row) return null;
        return {
            ...row,
            enabled: !!row.enabled,
            quickBan: !!row.quickBan,
            whitelist: deserialize(row.whitelist),
            extraOwners: deserialize(row.extraOwners),
            actions: deserialize(row.actions, {}),
            thresholds: deserialize(row.thresholds, {}),
            revert: deserialize(row.revert, {})
        };
    },
    set: async (guildId, data) => {
        await AntiNukeModel.findOneAndUpdate({ guildId }, data, { upsert: true });
    }
};

managers.ticketconfig = {
    get: async (guildId) => {
        const row = await TicketConfigModel.findOne({ guildId }).lean();
        if (!row) return null;
        return { ...row, categories: deserialize(row.categories, []) };
    },
    set: async (guildId, data) => {
        await TicketConfigModel.findOneAndUpdate({ guildId }, data, { upsert: true });
    },
    delete: async (guildId) => {
        await TicketConfigModel.deleteOne({ guildId });
    }
};

managers.tickets = {
    get: async (channelId) => {
        return await TicketsModel.findOne({ channelId }).lean();
    },
    set: async (channelId, data) => {
        await TicketsModel.findOneAndUpdate({ channelId }, data, { upsert: true });
    },
    delete: async (channelId) => {
        await TicketsModel.deleteOne({ channelId });
    },
    getOpenForUser: async (guildId, userId) => {
        return await TicketsModel.findOne({ guildId, userId, status: 'open' }).lean();
    },
    getActiveForGuild: async (guildId) => {
        return await TicketsModel.find({ guildId, status: 'open' }).lean();
    },
    getClosedForGuild: async (guildId) => {
        return await TicketsModel.find({ guildId, status: 'closed' }).lean();
    }
};

managers.autoresponders = {
    get: async (guildId, trigger) => {
        return await AutorespondersModel.findOne({ guildId, trigger }).lean();
    },
    add: async (guildId, trigger, reply) => {
        await AutorespondersModel.findOneAndUpdate({ guildId, trigger }, { reply }, { upsert: true });
    },
    remove: async (guildId, trigger) => {
        await AutorespondersModel.deleteOne({ guildId, trigger });
    },
    getForGuild: async (guildId) => {
        return await AutorespondersModel.find({ guildId }).lean();
    },
    deleteForGuild: async (guildId) => {
        await AutorespondersModel.deleteMany({ guildId });
    }
};

module.exports = managers;
