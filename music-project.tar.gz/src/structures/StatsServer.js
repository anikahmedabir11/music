const express = require("express");
const cors = require("cors");
const session = require("express-session");
const fs = require("fs");
const path = require("path");
const os = require("os");
const axios = require("axios");
const config = require("../config");
const { PermissionFlagsBits } = require("discord.js");

/**
 * stats-server.js
 * ----------------
 * REST API that powers the "Live Stats" and "Viewer Count" sections on the
 * website (index.html). Matches the fetch calls already wired up there:
 *
 *   GET  /stats             -> bot + system stats, same numbers as /stats in Discord
 *   POST /viewer-heartbeat  -> { id }  marks a browser tab as "currently viewing"
 *   GET  /viewers           -> { count }  people actively on the site right now
 *   POST /view-ping         -> increments the all-time page view counter
 *   GET  /total-views       -> { total }  all-time page views (persisted to disk)
 *
 * Usage (in your main bot file, after client.connect()):
 *
 *   const StatsServer = require("./src/structures/StatsServer");
 *   client.statsServer = new StatsServer(client, {
 *     port: process.env.STATS_API_PORT || 3001,
 *     corsOrigin: "https://YOURDOMAIN.com", // your real site domain
 *   });
 *
 * Then in index.html, replace:
 *   const VIEWERS_API_BASE = "https://api.yourdomain.com";
 *   const STATS_API_URL   = "https://api.yourdomain.com/stats";
 * with your real API domain (see hosting notes at the bottom of this file).
 */
class StatsServer {
  constructor(client, opts = {}) {
    this.client = client;
    this.port = opts.port || 3001;
    this.corsOrigin = opts.corsOrigin || "*";
    this.dataFile =
      opts.dataFile || path.join(__dirname, "..", "..", "viewdata.json");

    // viewerId -> last heartbeat timestamp (ms)
    this.activeViewers = new Map();
    this.viewerTimeoutMs = opts.viewerTimeoutMs || 25000; // drop after ~2.5 missed pings

    this.totalViews = this.loadTotalViews();

    this.app = express();
    this.app.use(cors({ origin: "*" }));
    this.app.use(express.json());
    
    // Setup sessions
    this.app.use(session({
      secret: "axc_music_super_secret_session_key",
      resave: false,
      saveUninitialized: false,
      cookie: { maxAge: 86400000 * 7 } // 7 days
    }));

    this.app.use(express.static(path.join(__dirname, "..", "..", "public")));

    this.registerRoutes();

    this.server = this.app.listen(this.port, () => {
      console.log(`[StatsServer] REST API listening on :${this.port}`);
    });

    // sweep stale viewers periodically
    this.sweepTimer = setInterval(() => this.sweepViewers(), 10000);
  }

  // ---------- persistence ----------

  loadTotalViews() {
    try {
      const raw = fs.readFileSync(this.dataFile, "utf8");
      const parsed = JSON.parse(raw);
      return Number(parsed.totalViews) || 0;
    } catch {
      return 0; // file doesn't exist yet or is unreadable — start fresh
    }
  }

  saveTotalViews() {
    try {
      fs.writeFileSync(
        this.dataFile,
        JSON.stringify({ totalViews: this.totalViews }, null, 2)
      );
    } catch (err) {
      console.log("[StatsServer] failed to persist view count:", err.message);
    }
  }

  // ---------- viewer tracking ----------

  sweepViewers() {
    const now = Date.now();
    for (const [id, lastSeen] of this.activeViewers) {
      if (now - lastSeen > this.viewerTimeoutMs) {
        this.activeViewers.delete(id);
      }
    }
  }

  // ---------- bot stats ----------

  gatherStats() {
    const client = this.client;
    const manager = client.manager;
    const players = manager ? Array.from(manager.players.values()) : [];
    const totalPlayers = players.length;
    const playingPlayers = players.filter((p) => p.playing).length;
    const idlePlayers = totalPlayers - playingPlayers;

    const cpuModel = os.cpus()[0]?.model.split(" @")[0].trim();
    const platform =
      os.platform().charAt(0).toUpperCase() + os.platform().slice(1);
    const load = os.loadavg();
    const cpuLoad = Number(((load[0] * 100) / os.cpus().length).toFixed(1));
    const ramMB = Number((process.memoryUsage().rss / 1024 / 1024).toFixed(2));

    return {
      servers: client.guilds.cache.size,
      users: client.users.cache.size,
      shard: `${(client.shard?.ids?.[0] ?? 0) + 1}/${client.shard?.count || 1}`,
      players: totalPlayers,
      playing: playingPlayers,
      idle: idlePlayers,
      ping: client.ws.ping,
      uptimeSeconds: Math.floor(process.uptime()),
      cpu: cpuModel,
      cpuLoad,
      ramMB,
      os: platform,
      node: process.version,
      djs: `v${require("discord.js").version}`,
      avatar: client.user ? client.user.displayAvatarURL({ forceStatic: false, size: 512 }) : null,
    };
  }

  // ---------- routes ----------

  registerRoutes() {
    const app = this.app;

    app.get("/stats", (req, res) => {
      res.json(this.gatherStats());
    });

    app.post("/viewer-heartbeat", (req, res) => {
      const id = req.body?.id;
      if (!id || typeof id !== "string") {
        return res.status(400).json({ error: "missing id" });
      }
      this.activeViewers.set(id, Date.now());
      res.json({ ok: true });
    });

    app.get("/viewers", (req, res) => {
      res.json({ count: this.activeViewers.size });
    });

    app.post("/view-ping", (req, res) => {
      this.totalViews += 1;
      this.saveTotalViews();
      res.json({ ok: true });
    });

    app.get("/total-views", (req, res) => {
      res.json({ total: this.totalViews });
    });

    // ---------- DISCORD OAUTH2 AUTH ROUTES ----------
    app.get("/api/auth/login", (req, res) => {
      const redirectUri = encodeURIComponent(config.links.redirectUri);
      const url = `https://discord.com/oauth2/authorize?client_id=${config.clientId}&response_type=code&redirect_uri=${redirectUri}&scope=identify%20guilds`;
      res.redirect(url);
    });

    app.get("/api/auth/callback", async (req, res) => {
      const { code } = req.query;
      if (!code) return res.redirect("/login.html?error=no_code");

      try {
        const tokenResponse = await axios.post("https://discord.com/api/oauth2/token", new URLSearchParams({
          client_id: config.clientId,
          client_secret: config.clientSecret,
          grant_type: "authorization_code",
          code,
          redirect_uri: config.links.redirectUri,
        }), {
          headers: { "Content-Type": "application/x-www-form-urlencoded" }
        });

        const { access_token } = tokenResponse.data;
        req.session.accessToken = access_token;

        // Redirect to dashboard page
        res.redirect("/dashboard.html");
      } catch (err) {
        console.error("[StatsServer] Auth callback failed:", err.response?.data || err.message);
        res.redirect("/login.html?error=auth_failed");
      }
    });

    app.get("/api/auth/logout", (req, res) => {
      req.session.destroy();
      res.redirect("/login.html");
    });

    app.get("/api/auth/user", async (req, res) => {
      if (!req.session.accessToken) return res.status(401).json({ error: "Unauthorized" });

      try {
        const userResponse = await axios.get("https://discord.com/api/users/@me", {
          headers: { Authorization: `Bearer ${req.session.accessToken}` }
        });
        res.json(userResponse.data);
      } catch (err) {
        res.status(401).json({ error: "Session expired" });
      }
    });

    // ---------- GUILD SELECTOR API ----------
    app.get("/api/guilds", async (req, res) => {
      if (!req.session.accessToken) return res.status(401).json({ error: "Unauthorized" });

      try {
        // Fetch user's servers
        const guildsResponse = await axios.get("https://discord.com/api/users/@me/guilds", {
          headers: { Authorization: `Bearer ${req.session.accessToken}` }
        });

        const userGuilds = guildsResponse.data;
        const botGuilds = this.client.guilds.cache;

        // Filter servers where the user has MANAGE_GUILD (0x20) permission
        const adminGuilds = userGuilds.filter(g => (BigInt(g.permissions) & 0x20n) === 0x20n).map(g => {
          const hasBot = botGuilds.has(g.id);
          const botIcon = hasBot ? botGuilds.get(g.id).iconURL({ size: 128 }) : null;
          return {
            id: g.id,
            name: g.name,
            icon: g.icon ? `https://cdn.discordapp.com/icons/${g.id}/${g.icon}.png` : null,
            hasBot,
            botIcon
          };
        });

        res.json(adminGuilds);
      } catch (err) {
        console.error("[StatsServer] Failed to fetch guilds:", err.message);
        res.status(500).json({ error: "Failed to fetch guilds" });
      }
    });

    // ---------- SETTINGS API ----------
    app.get("/api/guilds/:guildId/settings", async (req, res) => {
      if (!req.session.accessToken) return res.status(401).json({ error: "Unauthorized" });
      const { guildId } = req.params;
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) return res.status(404).json({ error: "Bot not in this guild" });

      try {
        // Fetch current user's profile from Discord to get their ID
        const userRes = await axios.get("https://discord.com/api/users/@me", {
          headers: { Authorization: `Bearer ${req.session.accessToken}` }
        });
        const userId = userRes.data.id;
        
        const settings = this.client.antinuke.getSettings(guildId);
        
        // Security check: Only Discord Server Owner, Extra Owners (in db), or Bot Owners (in config) can view/manage configurations.
        const isAllowed = this.client.antinuke.canManage(userId, guild, settings);
        if (!isAllowed) {
          return res.status(403).json({ error: "Only Guild Owners or designated AntiNuke managers can access these settings." });
        }

        const prefixData = this.client.db.prefixes.get(guildId);
        const serverPrefix = prefixData ? prefixData.prefix : config.prefix;
        const automodData = await this.client.db.automod.get(guildId) || {
          antiLink: false,
          antiInvite: false,
          antiSpam: false,
          antiMention: false,
          antiCaps: false,
          antiEmoji: false,
          antiNsfw: false
        };
        const welcomeData = await this.client.db.welcome.get(guildId) || {
          enabled: false,
          channelId: "",
          message: "Welcome {user.mention} to **{server}**! You are member #{membercount}."
        };
        const tfsevenData = await this.client.db.twofourseven.get(guildId) || null;
        const inviteTrackingData = await this.client.db.invitetracking.get(guildId) || { enabled: false };

        res.json({
          guildName: guild.name,
          guildIcon: guild.iconURL({ size: 128 }),
          prefix: serverPrefix,
          antinuke: settings,
          automod: automodData,
          welcome: welcomeData,
          twofourseven: !!tfsevenData,
          invitetracking: inviteTrackingData
        });
      } catch (err) {
        res.status(500).json({ error: "Error verifying user credentials" });
      }
    });

    app.post("/api/guilds/:guildId/settings", async (req, res) => {
      if (!req.session.accessToken) return res.status(401).json({ error: "Unauthorized" });
      const { guildId } = req.params;

      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) return res.status(404).json({ error: "Bot not in this guild" });

      try {
        const userRes = await axios.get("https://discord.com/api/users/@me", {
          headers: { Authorization: `Bearer ${req.session.accessToken}` }
        });
        const userId = userRes.data.id;
        const settings = this.client.antinuke.getSettings(guildId);

        const isAllowed = this.client.antinuke.canManage(userId, guild, settings);
        if (!isAllowed) {
          return res.status(403).json({ error: "Only Guild Owners or designated managers can modify settings." });
        }

        const { antinuke, prefix, automod, welcome, twofourseven, invitetracking } = req.body;

        if (antinuke) {
          this.client.antinuke.updateSettings(guildId, antinuke);
        }

        if (prefix && typeof prefix === "string" && prefix.length <= 5) {
          this.client.db.prefixes.set(guildId, { prefix });
        }

        if (automod) {
          await this.client.db.automod.set(guildId, automod);
        }

        if (welcome) {
          await this.client.db.welcome.set(guildId, welcome);
        }

        if (twofourseven !== undefined) {
          if (twofourseven) {
            await this.client.db.twofourseven.set(guildId, { textId: "default", voiceId: "default" });
          } else {
            await this.client.db.twofourseven.delete(guildId);
          }
        }

        if (invitetracking) {
          await this.client.db.invitetracking.set(guildId, invitetracking);
        }

        res.json({ ok: true });
      } catch (err) {
        res.status(500).json({ error: "Error updating settings" });
      }
    });


    // ---------- LIVE MUSIC PLAYER CONTROL API ----------
    app.get("/api/guilds/:guildId/player", (req, res) => {
      if (!req.session.accessToken) return res.status(401).json({ error: "Unauthorized" });
      const { guildId } = req.params;
      const player = this.client.manager?.players.get(guildId);
      if (!player) return res.json({ active: false });

      res.json({
        active: true,
        playing: player.playing,
        paused: player.paused,
        track: player.queue?.current ? {
          title: player.queue.current.title,
          author: player.queue.current.author,
          duration: player.queue.current.length,
          uri: player.queue.current.uri
        } : null
      });
    });

    app.post("/api/guilds/:guildId/player/control", async (req, res) => {
      if (!req.session.accessToken) return res.status(401).json({ error: "Unauthorized" });
      const { guildId } = req.params;
      const { action } = req.body; // play, pause, skip

      try {
        // Fetch user's servers to verify they have MANAGE_GUILD permission in this guild
        const userGuildsRes = await axios.get("https://discord.com/api/users/@me/guilds", {
          headers: { Authorization: `Bearer ${req.session.accessToken}` }
        });
        const userGuild = userGuildsRes.data.find(g => g.id === guildId);
        if (!userGuild || (BigInt(userGuild.permissions) & 0x20n) !== 0x20n) {
          return res.status(403).json({ error: "Only Server Managers with Manage Guild permission can control the player." });
        }

        const player = this.client.manager?.players.get(guildId);
        if (!player) return res.status(404).json({ error: "No active music player" });

        if (action === "pause") {
          player.pause(true);
        } else if (action === "play") {
          player.pause(false);
        } else if (action === "skip") {
          await player.skip();
        }

        res.json({ ok: true });
      } catch (err) {
        res.status(500).json({ error: "Error verifying permissions" });
      }
    });
  }

  stop() {
    clearInterval(this.sweepTimer);
    this.server.close();
  }
}

module.exports = StatsServer;

/**
 * Hosting notes:
 * - npm install express cors
 * - Run this behind your reverse proxy (nginx/Caddy) so it's reachable as
 *   https://api.yourdomain.com (TLS + your real domain), forwarding to
 *   127.0.0.1:3001 (or whatever STATS_API_PORT you set).
 * - Set corsOrigin to your actual site origin (e.g. "https://zyvora.xyz")
 *   instead of "*" once you're live, so random sites can't hit your API.
 * - viewdata.json is created next to your bot's root folder automatically —
 *   make sure that path is writable.
 */
