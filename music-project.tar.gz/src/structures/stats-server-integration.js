/**
 * Add this to your main bot file (index.js / bot.js), AFTER client.login()
 * or after your ready event fires — StatsServer reads live client data,
 * so the client needs to be connected first.
 */

const StatsServer = require("./src/structures/StatsServer");

client.once("ready", () => {
  client.statsServer = new StatsServer(client, {
    port: process.env.STATS_API_PORT || 3001,
    // Lock this down to your real site domain once deployed —
    // "*" is fine for local testing only.
    corsOrigin: process.env.NODE_ENV === "production"
      ? "https://zyvora.xyz"          // <- swap for your real domain
      : "*",
  });
});

/**
 * Dependencies (install if not already present):
 *   npm install express cors
 *
 * Deployment note:
 * Run this behind a reverse proxy (nginx/Caddy) so the landing page can
 * reach it over HTTPS as e.g. https://api.zyvora.xyz, forwarded to
 * 127.0.0.1:3001. Then in zyvora-landing.html, set:
 *   const API_BASE = "https://api.zyvora.xyz";
 *
 * If you're only testing locally right now, leave API_BASE as
 * "http://localhost:3001", run the bot, and open the landing page —
 * the live-dot indicator will turn gold once it connects.
 */
