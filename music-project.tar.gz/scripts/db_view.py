#!/usr/bin/env python3
import argparse
import csv
import json
import os
import sqlite3
import sys
from pathlib import Path


def connect_readonly(db_path: Path) -> sqlite3.Connection:
    uri = f"file:{db_path.as_posix()}?mode=ro"
    return sqlite3.connect(uri, uri=True)


def get_tables(conn: sqlite3.Connection):
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()
    return [r[0] for r in rows]


def print_rows(headers, rows):
    if not rows:
        print("No rows found.")
        return

    widths = [len(str(h)) for h in headers]
    for row in rows:
        for i, val in enumerate(row):
            widths[i] = max(widths[i], len(str(val)))

    def format_row(values):
        return " | ".join(str(v).ljust(widths[i]) for i, v in enumerate(values))

    print(format_row(headers))
    print("-+-".join("-" * w for w in widths))
    for row in rows:
        print(format_row(row))


def cmd_tables(conn):
    tables = get_tables(conn)
    if not tables:
        print("No user tables found.")
        return
    print_rows(["#", "table"], [(i + 1, name) for i, name in enumerate(tables)])


def cmd_counts(conn):
    tables = get_tables(conn)
    data = []
    for table in tables:
        count = conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
        data.append((table, count))
    print_rows(["table", "rows"], data)


def cmd_schema(conn, table):
    rows = conn.execute(f'PRAGMA table_info("{table}")').fetchall()
    if not rows:
        print(f"Table not found: {table}")
        sys.exit(1)
    print_rows(["cid", "name", "type", "notnull", "dflt_value", "pk"], rows)


def cmd_head(conn, table, limit):
    cur = conn.execute(f'SELECT * FROM "{table}" LIMIT ?', (limit,))
    rows = cur.fetchall()
    headers = [d[0] for d in cur.description] if cur.description else []
    if not headers:
        print(f"Table not found or has no columns: {table}")
        sys.exit(1)
    print_rows(headers, rows)


def cmd_export(conn, table, fmt, out_path, limit):
    sql = f'SELECT * FROM "{table}"'
    params = ()
    if limit:
        sql += ' LIMIT ?'
        params = (limit,)

    cur = conn.execute(sql, params)
    rows = cur.fetchall()
    headers = [d[0] for d in cur.description] if cur.description else []

    if fmt == "json":
        objects = [dict(zip(headers, row)) for row in rows]
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(objects, f, indent=2)
    else:
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(rows)

    print(f"Exported {len(rows)} row(s) to: {out_path}")


def cmd_export_all(conn, out_dir, fmt, limit):
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    tables = get_tables(conn)
    counts = []
    all_data = {}

    for table in tables:
        sql = f'SELECT * FROM "{table}"'
        params = ()
        if limit:
            sql += ' LIMIT ?'
            params = (limit,)

        cur = conn.execute(sql, params)
        rows = cur.fetchall()
        headers = [d[0] for d in cur.description] if cur.description else []
        objects = [dict(zip(headers, row)) for row in rows]
        counts.append({"table": table, "rows": len(objects)})
        all_data[table] = objects

        if fmt == "json":
            file_path = out_path / f"{table}.json"
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(objects, f, indent=2)
        else:
            file_path = out_path / f"{table}.csv"
            with open(file_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(headers)
                writer.writerows(rows)

    with open(out_path / "table_counts.json", "w", encoding="utf-8") as f:
        json.dump(counts, f, indent=2)

    with open(out_path / "all_tables.json", "w", encoding="utf-8") as f:
        json.dump(all_data, f, indent=2)

    print(f"Exported {len(tables)} table(s) to: {out_path.resolve()}")
    print(f"Summary files: {(out_path / 'table_counts.json').resolve()}, {(out_path / 'all_tables.json').resolve()}")


def cmd_query(conn, sql):
    first = sql.strip().split()[0].lower() if sql.strip() else ""
    if first not in {"select", "pragma", "with"}:
        print("Only read queries are allowed: SELECT / PRAGMA / WITH")
        sys.exit(1)

    cur = conn.execute(sql)
    rows = cur.fetchall()
    headers = [d[0] for d in cur.description] if cur.description else []
    if headers:
        print_rows(headers, rows)
    else:
        print("Query executed.")


def build_parser():
    parser = argparse.ArgumentParser(description="SQLite DB Viewer")
    parser.add_argument("--db", default="database.db", help="Path to SQLite DB file")

    sub = parser.add_subparsers(dest="command", required=False)

    sub.add_parser("tables")
    sub.add_parser("counts")

    p_schema = sub.add_parser("schema")
    p_schema.add_argument("table")

    p_head = sub.add_parser("head")
    p_head.add_argument("table")
    p_head.add_argument("limit", nargs="?", type=int, default=20)

    p_export = sub.add_parser("export")
    p_export.add_argument("table")
    p_export.add_argument("--format", choices=["csv", "json"], default="csv")
    p_export.add_argument("--out", default=None)
    p_export.add_argument("--limit", type=int, default=None)

    p_export_all = sub.add_parser("export-all")
    p_export_all.add_argument("--format", choices=["csv", "json"], default="json")
    p_export_all.add_argument("--out-dir", default="db_exports")
    p_export_all.add_argument("--limit", type=int, default=None)

    p_query = sub.add_parser("query")
    p_query.add_argument("sql")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    command = args.command or "tables"

    db_path = Path(args.db).resolve()
    if not db_path.exists():
        print(f"Database file not found: {db_path}")
        sys.exit(1)

    conn = connect_readonly(db_path)
    try:
        if command == "tables":
            cmd_tables(conn)
        elif command == "counts":
            cmd_counts(conn)
        elif command == "schema":
            cmd_schema(conn, args.table)
        elif command == "head":
            cmd_head(conn, args.table, args.limit)
        elif command == "export":
            out = args.out or f"{args.table}.{args.format}"
            cmd_export(conn, args.table, args.format, out, args.limit)
        elif command == "export-all":
            cmd_export_all(conn, args.out_dir, args.format, args.limit)
        elif command == "query":
            cmd_query(conn, args.sql)
        else:
            parser.print_help()
            sys.exit(1)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
