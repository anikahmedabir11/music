#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const BetterSqlite3 = require('better-sqlite3');

const args = process.argv.slice(2);
const command = (args[0] || 'tables').toLowerCase();

function getFlagValue(flag) {
  const index = args.findIndex((a) => a === flag || a.startsWith(`${flag}=`));
  if (index === -1) return undefined;
  const token = args[index];
  if (token.includes('=')) return token.split('=').slice(1).join('=');
  return args[index + 1];
}

function toPositiveInt(value, fallback) {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) return fallback;
  return n;
}

function isSafeIdentifier(name) {
  return /^[A-Za-z_][A-Za-z0-9_]*$/.test(name);
}

function quoteIdentifier(name) {
  if (!isSafeIdentifier(name)) {
    throw new Error(`Invalid table name: ${name}`);
  }
  return `"${name}"`;
}

function csvEscape(value) {
  if (value === null || value === undefined) return '';
  const str = typeof value === 'string' ? value : JSON.stringify(value);
  if (/[",\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function toCsv(rows) {
  if (!rows.length) return '';
  const columns = Object.keys(rows[0]);
  const header = columns.map(csvEscape).join(',');
  const lines = rows.map((row) => columns.map((col) => csvEscape(row[col])).join(','));
  return [header, ...lines].join('\n');
}

function printHelp() {
  console.log(`\nDB Viewer (SQLite)\n\nUsage:\n  node scripts/db-view.js tables\n  node scripts/db-view.js counts\n  node scripts/db-view.js schema <table>\n  node scripts/db-view.js head <table> [limit]\n  node scripts/db-view.js export <table> [--format=csv|json] [--out <path>] [--limit <n>]\n  node scripts/db-view.js query "<sql>"\n\nOptions:\n  --db <path>        SQLite file path (default: ./database.db)\n  --limit <n>        Row limit for head/export (default: 20 for head, all for export)\n\nExamples:\n  node scripts/db-view.js tables\n  node scripts/db-view.js counts\n  node scripts/db-view.js schema profiles\n  node scripts/db-view.js head profiles 10\n  node scripts/db-view.js export profiles --format=csv --out ./profiles.csv --limit=100\n  node scripts/db-view.js query "SELECT * FROM profiles LIMIT 5"\n`);
}

const dbPath = path.resolve(process.cwd(), getFlagValue('--db') || 'database.db');
if (!fs.existsSync(dbPath)) {
  console.error(`Database file not found: ${dbPath}`);
  process.exit(1);
}

const db = new BetterSqlite3(dbPath, { readonly: true });

function getTables() {
  return db
    .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    .all()
    .map((r) => r.name);
}

try {
  if (command === 'help' || command === '--help' || command === '-h') {
    printHelp();
    process.exit(0);
  }

  if (command === 'tables') {
    const tables = getTables();
    if (!tables.length) {
      console.log('No user tables found.');
      process.exit(0);
    }
    console.table(tables.map((name, i) => ({ '#': i + 1, table: name })));
    process.exit(0);
  }

  if (command === 'counts') {
    const tables = getTables();
    const result = tables.map((name) => {
      const safeName = quoteIdentifier(name);
      const row = db.prepare(`SELECT COUNT(*) AS count FROM ${safeName}`).get();
      return { table: name, rows: row.count };
    });
    console.table(result);
    process.exit(0);
  }

  if (command === 'schema') {
    const table = args[1];
    if (!table) {
      console.error('Missing table name. Example: node scripts/db-view.js schema profiles');
      process.exit(1);
    }
    quoteIdentifier(table);
    const schema = db.prepare(`PRAGMA table_info(${quoteIdentifier(table)})`).all();
    if (!schema.length) {
      console.error(`Table not found: ${table}`);
      process.exit(1);
    }
    console.table(schema);
    process.exit(0);
  }

  if (command === 'head') {
    const table = args[1];
    if (!table) {
      console.error('Missing table name. Example: node scripts/db-view.js head profiles 10');
      process.exit(1);
    }
    const limit = toPositiveInt(args[2] || getFlagValue('--limit'), 20);
    const safeName = quoteIdentifier(table);
    const rows = db.prepare(`SELECT * FROM ${safeName} LIMIT ?`).all(limit);
    if (!rows.length) {
      console.log(`No rows found in ${table}.`);
      process.exit(0);
    }
    console.table(rows);
    process.exit(0);
  }

  if (command === 'export') {
    const table = args[1];
    if (!table) {
      console.error('Missing table name. Example: node scripts/db-view.js export profiles --format=csv');
      process.exit(1);
    }
    const format = (getFlagValue('--format') || 'csv').toLowerCase();
    const limit = toPositiveInt(getFlagValue('--limit'), undefined);
    const safeName = quoteIdentifier(table);

    const sql = limit ? `SELECT * FROM ${safeName} LIMIT ?` : `SELECT * FROM ${safeName}`;
    const rows = limit ? db.prepare(sql).all(limit) : db.prepare(sql).all();

    const defaultFile = `${table}.${format === 'json' ? 'json' : 'csv'}`;
    const outPath = path.resolve(process.cwd(), getFlagValue('--out') || defaultFile);

    if (format === 'json') {
      fs.writeFileSync(outPath, JSON.stringify(rows, null, 2), 'utf8');
    } else {
      fs.writeFileSync(outPath, toCsv(rows), 'utf8');
    }

    console.log(`Exported ${rows.length} row(s) to: ${outPath}`);
    process.exit(0);
  }

  if (command === 'query') {
    const sql = args.slice(1).join(' ').trim();
    if (!sql) {
      console.error('Missing SQL query. Example: node scripts/db-view.js query "SELECT * FROM profiles LIMIT 5"');
      process.exit(1);
    }
    const stmt = db.prepare(sql);
    if (stmt.reader) {
      const rows = stmt.all();
      console.table(rows);
    } else {
      console.error('Only SELECT-like read queries are allowed in this viewer.');
      process.exit(1);
    }
    process.exit(0);
  }

  console.error(`Unknown command: ${command}`);
  printHelp();
  process.exit(1);
} catch (error) {
  console.error(`Error: ${error.message}`);
  process.exit(1);
} finally {
  db.close();
}
